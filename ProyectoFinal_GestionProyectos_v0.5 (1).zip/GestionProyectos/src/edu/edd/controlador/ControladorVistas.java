package edu.edd.controlador;

import edu.edd.modelo.Estudiante;
import edu.edd.modelo.Proyecto;
import edu.edd.modelo.Tarea;
import edu.edd.modelo.Usuario;
import edu.edd.vista.VistaInicio;
import edu.edd.vista.acerca.VistaAcerca;
import edu.edd.vista.proyecto.VistaCrearProyecto;
import edu.edd.vista.proyecto.VistaDetalladaProyecto;
import edu.edd.vista.proyecto.VistaEditarProyecto;
import edu.edd.vista.proyecto.VistaListarProyectos;
import edu.edd.vista.tarea.VistaCrearTarea;
import edu.edd.vista.tarea.VistaEditarTarea;
import edu.edd.vista.tarea.VistaManejarTareas;
import edu.edd.vista.usuario.DialogoCrearUsuario;
import edu.edd.vista.usuario.VistaSeleccionarUsuario;
import java.util.function.Consumer;
import javafx.scene.control.Dialog;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ControladorVistas {

    public static Dialog<Boolean> crearUsuario() {
        DialogoCrearUsuario dialogoCrearUsuario = new DialogoCrearUsuario(400, 300);
        return dialogoCrearUsuario.getDialogo();
    }

    public static VBox seleccionarUsuario(Consumer<Usuario> callbackSeleccion, double ancho, double alto) {
        VistaSeleccionarUsuario vistaSeleccionarUsuario
                = new VistaSeleccionarUsuario(callbackSeleccion, ancho, alto);
        return vistaSeleccionarUsuario.getContenedor();
    }

    public static VBox verInicio(Usuario usuario, double ancho, double alto) {
        VistaInicio vistaInicio = new VistaInicio(ancho, alto);
        return vistaInicio.getContenedor();
    }

    public static VBox verProyectos(Usuario usuario, BorderPane panelPrimario,
            Pane panelCentral, double ancho, double alto) {
        VistaListarProyectos vistaListarProyectos
                = new VistaListarProyectos(usuario, panelPrimario, panelCentral,
                        ancho, alto);
        return vistaListarProyectos.getContenedor();
    }

    public static VBox crearProyecto(Usuario usuario, BorderPane panelPrimario,
            Pane panelCentral, double ancho, double alto) {
        VistaCrearProyecto vistaCrearProyecto
                = new VistaCrearProyecto(usuario, panelPrimario, panelCentral,
                        ancho, alto);
        return vistaCrearProyecto.getContenedor();
    }

    public static VBox editarProyecto(Usuario usuario, Proyecto proyecto, BorderPane panelPrimario,
            Pane panelCentral, double ancho, double alto) {
        VistaEditarProyecto vistaEditarProyecto = new VistaEditarProyecto((Estudiante) usuario,
                proyecto, panelPrimario, panelCentral, ancho, alto);
        return vistaEditarProyecto.getContenedor();
    }

    public static VBox manejarTareas(Usuario usuario, Proyecto proyecto, BorderPane panelPrimario,
            Pane panelCentral, double ancho, double alto) {
        VistaManejarTareas vistaManejarTareas = new VistaManejarTareas(usuario,
                proyecto, panelPrimario, panelCentral, ancho, alto);
        return vistaManejarTareas.getContenedor();
    }

    public static VBox crearTarea(Usuario usuario, Proyecto proyecto, BorderPane panelPrimario,
            Pane panelCentral, double ancho, double alto) {
        VistaCrearTarea vistaCrearTarea
                = new VistaCrearTarea(usuario, proyecto, panelPrimario,
                        panelCentral, ancho, alto);
        return vistaCrearTarea.getContenedor();
    }

    public static VBox editarTarea(Usuario usuario, Proyecto proyecto, Tarea tarea,
            BorderPane panelPrimario, Pane panelCentral, double ancho, double alto) {
        VistaEditarTarea vistaEditarTarea
                = new VistaEditarTarea(usuario, proyecto, tarea, panelPrimario,
                        panelCentral, ancho, alto);
        return vistaEditarTarea.getContenedor();
    }

    public static Pane buscarProyectos(Usuario usuario, double ancho, double alto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public static Stage verAcerca() {
        VistaAcerca vistaAcerca = new VistaAcerca(400, 300);
        Stage escenario = vistaAcerca.getEscenario();
        escenario.setTitle("Acerca de...");
        escenario.initModality(Modality.APPLICATION_MODAL);
        return escenario;
    }

    public static Pane verDetallesProyecto(Usuario usuario, Proyecto proyecto, BorderPane panelPrimario, Pane panelCentral, double ancho, double alto) {
        VistaDetalladaProyecto vistaDetalladaProyecto
                = new VistaDetalladaProyecto(usuario, proyecto, panelPrimario,
                        panelCentral, ancho, alto);
        return vistaDetalladaProyecto.getContenedor();
    }

}
