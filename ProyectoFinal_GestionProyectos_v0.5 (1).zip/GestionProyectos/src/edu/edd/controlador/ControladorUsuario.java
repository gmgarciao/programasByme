package edu.edd.controlador;

import edu.edd.modelo.Estudiante;
import edu.edd.modelo.Usuario;
import edu.edd.persistencia.DaoUsuario;
import edu.edd.recurso.dominio.Configuracion;
import java.util.List;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Modality;

public class ControladorUsuario {

    private static boolean esInformacionValida(String... strings) {
        String s = "";
        for (String string : strings) {
            s += string;
        }
        return !s.contains(Configuracion.SEPARADOR_COLUMNA)
                && !s.contains(Configuracion.INDICADOR_INICIO_LISTA)
                && !s.contains(Configuracion.INDICADOR_FIN_LISTA);
    }

    public static Optional<Usuario> obtenerUsuario(int indice) {
        DaoUsuario dao = new DaoUsuario();
        return dao.leerRegistro(indice);
    }

    public static List<Usuario> obtenerUsuarios(List<Integer> indices) {
        DaoUsuario dao = new DaoUsuario();
        return dao.leerRegistros(indices);
    }

    public static Optional<Usuario> obtenerUsuarioPorId(int id) {
        DaoUsuario dao = new DaoUsuario();
        return dao.leerRegistroPorId(id);
    }

    public static List<Usuario> obtenerUsuariosPorId(List<Integer> ids) {
        DaoUsuario dao = new DaoUsuario();
        return dao.leerRegistrosPorId(ids);
    }

    public static Optional<Usuario> grabar(String tipo, String nombreUsuario) {
        if (nombreUsuario.length() == 0 || !esInformacionValida(nombreUsuario)) {
            return Optional.empty();
        }
        DaoUsuario dao = new DaoUsuario();
        int idUsuario = dao.getIdSerial();
        Usuario usuario;
        if ("Estudiante".equals(tipo)) {
            usuario = new Estudiante(idUsuario, nombreUsuario,
                    FXCollections.observableArrayList());
        } else {
            usuario = new Usuario(idUsuario, nombreUsuario);
        }
        if (dao.insertarRegistro(usuario)) {
            return Optional.of(usuario);
        } else {
            return Optional.empty();
        }
    }

    public static Optional<Usuario> actualizar(Usuario usuario, String nombreUsuario) {
        if (nombreUsuario.length() == 0 || !esInformacionValida(nombreUsuario)) {
            return Optional.empty();
        }
        DaoUsuario dao = new DaoUsuario();
        int idUsuario = usuario.getIdUsuario();
        if (Estudiante.class.equals(usuario.getClass())) {
            Estudiante estudiante = (Estudiante) usuario;
            usuario = new Estudiante(idUsuario, nombreUsuario,
                    estudiante.getProyectosEstudiante());
        } else {
            usuario = new Usuario(idUsuario, nombreUsuario);
        }
        if (dao.actualizarRegistro(usuario)) {
            return Optional.of(usuario);
        } else {
            return Optional.empty();
        }
    }

    public static Optional<Usuario> actualizar(Usuario usuario) {
        DaoUsuario dao = new DaoUsuario();
        if (dao.actualizarRegistro(usuario)) {
            return Optional.of(usuario);
        } else {
            return Optional.empty();
        }
    }

    public static boolean eliminar(Usuario usuario) {
        Alert mensaje = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Esta seguro de que quiere eliminar esta cuenta?", ButtonType.NO, ButtonType.YES);
        mensaje.setHeaderText("Confirmar eliminacion");
        mensaje.initModality(Modality.APPLICATION_MODAL);
        if (mensaje.showAndWait().get().equals(ButtonType.YES)) {
            DaoUsuario dao = new DaoUsuario();
            if (dao.eliminarRegistro(usuario.getIdUsuario())) {
                return true;
            } else {
                Alert error = new Alert(Alert.AlertType.ERROR,
                        "No se pudo eliminar el usuario.", ButtonType.CLOSE);
                error.initModality(Modality.APPLICATION_MODAL);
                error.show();
            }
        } else {
            mensaje.close();
        }
        return false;
    }

    public static ObservableList<Usuario> cargar() {
        DaoUsuario dao = new DaoUsuario();
        return FXCollections.observableList(dao.leerRegistros());
    }
}
