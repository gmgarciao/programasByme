package edu.edd.controlador;

import edu.edd.modelo.Proyecto;
import edu.edd.persistencia.DaoProyecto;
import edu.edd.recurso.dominio.Configuracion;
import java.util.List;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Modality;

public class ControladorProyecto {

    private static boolean esInformacionValida(String... strings) {
        String s = "";
        for (String string : strings) {
            s += string;
        }
        return !s.contains(Configuracion.SEPARADOR_COLUMNA)
                && !s.contains(Configuracion.INDICADOR_INICIO_LISTA)
                && !s.contains(Configuracion.INDICADOR_FIN_LISTA);
    }

    public static Optional<Proyecto> obtenerProyecto(int indice) {
        DaoProyecto dao = new DaoProyecto();
        return dao.leerRegistro(indice);
    }

    public static List<Proyecto> obtenerProyectos(List<Integer> indices) {
        DaoProyecto dao = new DaoProyecto();
        return dao.leerRegistros(indices);
    }

    public static Optional<Proyecto> obtenerProyectoPorId(int id) {
        DaoProyecto dao = new DaoProyecto();
        return dao.leerRegistroPorId(id);
    }

    public static List<Proyecto> obtenerProyectosPorId(List<Integer> ids) {
        DaoProyecto dao = new DaoProyecto();
        return dao.leerRegistrosPorId(ids);
    }

    public static Optional<Proyecto> grabar(String tituloProyecto, String descripcionProyecto, List<String> miembrosProyecto) {
        if (tituloProyecto.length() == 0 || !esInformacionValida(tituloProyecto)
                || !esInformacionValida(miembrosProyecto.toArray(String[]::new))) {
            return Optional.empty();
        }
        DaoProyecto dao = new DaoProyecto();
        int idProyecto = dao.getIdSerial();
        Proyecto proyecto = new Proyecto(idProyecto, tituloProyecto,
                descripcionProyecto, FXCollections.observableList(miembrosProyecto),
                FXCollections.observableArrayList(), false);
        if (dao.insertarRegistro(proyecto)) {
            return Optional.of(proyecto);
        } else {
            return Optional.empty();
        }
    }

    public static Optional<Proyecto> actualizar(Proyecto proyecto, String tituloProyecto, String descripcionProyecto, List<String> miembrosProyecto, boolean completitudProyecto) {
        if (tituloProyecto.length() == 0 || !esInformacionValida(tituloProyecto)
                || !esInformacionValida(miembrosProyecto.toArray(String[]::new))) {
            return Optional.empty();
        }
        DaoProyecto dao = new DaoProyecto();
        proyecto.setTituloProyecto(tituloProyecto);
        proyecto.setDescripcionProyecto(descripcionProyecto);
        proyecto.setMiembrosProyecto(FXCollections.observableList(miembrosProyecto));
        proyecto.setCompletitudProyecto(completitudProyecto);
        if (dao.actualizarRegistro(proyecto)) {
            return Optional.of(proyecto);
        } else {
            return Optional.empty();
        }
    }

    public static Optional<Proyecto> actualizar(Proyecto proyecto) {
        DaoProyecto dao = new DaoProyecto();
        if (dao.actualizarRegistro(proyecto)) {
            return Optional.of(proyecto);
        } else {
            return Optional.empty();
        }
    }

    public static boolean eliminar(Proyecto proyecto) {
        Alert mensaje = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Esta seguro de que quiere eliminar este proyecto?", ButtonType.NO, ButtonType.YES);
        mensaje.setHeaderText("Confirmar eliminacion");
        mensaje.initModality(Modality.APPLICATION_MODAL);
        if (mensaje.showAndWait().get().equals(ButtonType.YES)) {
            DaoProyecto dao = new DaoProyecto();
            if (dao.eliminarRegistro(proyecto.getIdProyecto())) {
                return true;
            } else {
                Alert error = new Alert(Alert.AlertType.ERROR,
                        "No se pudo eliminar el proyecto.", ButtonType.CLOSE);
                error.initModality(Modality.APPLICATION_MODAL);
                error.show();
            }
        } else {
            mensaje.close();
        }
        return false;
    }

    public static ObservableList<Proyecto> cargarProyectos() {
        DaoProyecto dao = new DaoProyecto();
        return FXCollections.observableList(dao.leerRegistros());
    }
}
