package edu.edd.controlador;

import edu.edd.modelo.Tarea;
import edu.edd.persistencia.DaoTarea;
import edu.edd.recurso.dominio.Configuracion;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Modality;

public class ControladorTarea {

    private static boolean esInformacionValida(String... strings) {
        String s = "";
        for (String string : strings) {
            s += string;
        }
        return !s.contains(Configuracion.SEPARADOR_COLUMNA)
                && !s.contains(Configuracion.INDICADOR_INICIO_LISTA)
                && !s.contains(Configuracion.INDICADOR_FIN_LISTA);
    }

    public static Optional<Tarea> obtenerTarea(int indice) {
        DaoTarea dao = new DaoTarea();
        return dao.leerRegistro(indice);
    }

    public static Optional<Tarea> grabar(String tituloTarea, String descripcionTarea, String responsableTarea) {
        if (tituloTarea.length() == 0 || !esInformacionValida(tituloTarea,
                descripcionTarea, responsableTarea)) {
            return Optional.empty();
        }
        DaoTarea dao = new DaoTarea();
        int idTarea = dao.getIdSerial();
        Tarea tarea = new Tarea(idTarea, tituloTarea, descripcionTarea,
                responsableTarea, false);
        if (dao.insertarRegistro(tarea)) {
            return Optional.of(tarea);
        } else {
            return Optional.empty();
        }
    }

    public static Optional<Tarea> actualizar(Tarea tarea, String tituloTarea, String descripcionTarea, String responsableTarea, boolean completitudTarea) {
        if (tituloTarea.length() == 0 || !esInformacionValida(tituloTarea,
                descripcionTarea, responsableTarea)) {
            return Optional.empty();
        }
        DaoTarea dao = new DaoTarea();
        int idTarea = tarea.getIdTarea();
        Tarea tareaActualizada = new Tarea(idTarea, tituloTarea, descripcionTarea,
                responsableTarea, completitudTarea);
        if (dao.actualizarRegistro(tareaActualizada)) {
            return Optional.of(tareaActualizada);
        } else {
            return Optional.empty();
        }
    }

    public static boolean eliminar(Tarea tarea) {
        Alert mensaje = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Esta seguro de que quiere eliminar esta tarea?", ButtonType.NO, ButtonType.YES);
        mensaje.setHeaderText("Confirmar eliminacion");
        mensaje.initModality(Modality.APPLICATION_MODAL);
        if (mensaje.showAndWait().get().equals(ButtonType.YES)) {
            DaoTarea dao = new DaoTarea();
            if (dao.eliminarRegistro(tarea.getIdTarea())) {
                return true;
            } else {
                Alert error = new Alert(Alert.AlertType.ERROR,
                        "No se pudo eliminar la tarea.", ButtonType.CLOSE);
                error.initModality(Modality.APPLICATION_MODAL);
                error.show();
            }
        } else {
            mensaje.close();
        }
        return false;
    }

    public static ObservableList<Tarea> cargar() {
        DaoTarea dao = new DaoTarea();
        return FXCollections.observableList(dao.leerRegistros());
    }

    public static Optional<Tarea> obtenerTareaPorId(int id) {
        DaoTarea dao = new DaoTarea();
        return dao.leerRegistroPorId(id);
    }
}
