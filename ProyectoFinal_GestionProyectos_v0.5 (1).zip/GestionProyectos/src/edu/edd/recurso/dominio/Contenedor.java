package edu.edd.recurso.dominio;

public enum Contenedor {
    CUERPO(Configuracion.ANCHO_APP, Configuracion.ALTO_APP * 0.8),
    CABECERA(Configuracion.ANCHO_APP, Configuracion.ALTO_APP * 0.2);

    private final double ancho;
    private final double alto;

    private Contenedor(double ancho, double alto) {
        this.ancho = ancho;
        this.alto = alto;
    }

    public double getAncho() {
        return ancho;
    }

    public double getAlto() {
        return alto;
    }
}
