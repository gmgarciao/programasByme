package edu.edd.recurso.dominio;

public class Ruta {

    public final static String RUTA_PROYECTO = System.getProperty("user.dir");
    public final static String RUTA_USUARIO = System.getProperty("user.home");
    public final static String RUTA_IMAGENES = "/edu/edd/recurso/imagen/";
    public final static String RUTA_PERSISTENCIA = RUTA_PROYECTO
            + Configuracion.SEPARADOR_DIRECTORIOS + "baseDatos";
}
