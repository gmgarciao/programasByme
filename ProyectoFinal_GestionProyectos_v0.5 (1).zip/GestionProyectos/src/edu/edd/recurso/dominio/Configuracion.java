package edu.edd.recurso.dominio;

public class Configuracion {

    public final static double ANCHO_APP = 800;
    public final static double ALTO_APP = 600;

    public final static String ARCHIVO_PROYECTOS = "registroProyectos.txt";
    public final static String ARCHIVO_TAREAS = "registroTareas.txt";
    public final static String ARCHIVO_USUARIOS = "registroUsuarios.txt";

    public final static String SEPARADOR_COLUMNA = ";";
    public final static String INDICADOR_INICIO_LISTA = "{";
    public final static String INDICADOR_FIN_LISTA = "}";
    public final static String SEPARADOR_DIRECTORIOS = "\\";
    public final static String SEPARADOR_LINEA = System.getProperty("line.separator");
}
