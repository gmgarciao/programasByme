package edu.edd.modelo;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Proyecto {

    private IntegerProperty idProyecto;
    private StringProperty tituloProyecto;
    private StringProperty descripcionProyecto;
    private ListProperty<String> miembrosProyecto;
    private ListProperty<Tarea> tareasProyecto;
    private BooleanProperty completitudProyecto;

    public Proyecto() {
    }

    public Proyecto(int idProyecto, String tituloProyecto,
            String descripcionProyecto, ObservableList<String> miembrosProyecto,
            ObservableList<Tarea> tareasProyecto, boolean completitudProyecto) {
        inicializar(idProyecto, tituloProyecto, descripcionProyecto,
                miembrosProyecto, tareasProyecto, completitudProyecto);
    }

    private void inicializar(int idProyecto, String tituloProyecto,
            String descripcionProyecto, ObservableList<String> miembrosProyecto,
            ObservableList<Tarea> tareasProyecto, boolean completitudProyecto) {

        setIdProyecto(idProyecto);
        setTituloProyecto(tituloProyecto);
        setDescripcionProyecto(descripcionProyecto);
        setMiembrosProyecto(miembrosProyecto);
        setTareasProyecto(tareasProyecto);
        setCompletitudProyecto(completitudProyecto);
    }

    public IntegerProperty propiedadIdProyecto() {
        if (idProyecto == null) {
            idProyecto = new SimpleIntegerProperty(this, "idProyecto");
        }
        return idProyecto;
    }

    public int getIdProyecto() {
        return propiedadIdProyecto().get();
    }

    public void setIdProyecto(int idProyecto) {
        propiedadIdProyecto().set(idProyecto);
    }

    public StringProperty propiedadTituloProyecto() {
        if (tituloProyecto == null) {
            tituloProyecto = new SimpleStringProperty(this, "tituloProyecto");
        }
        return tituloProyecto;
    }

    public String getTituloProyecto() {
        return propiedadTituloProyecto().get();
    }

    public void setTituloProyecto(String tituloProyecto) {
        propiedadTituloProyecto().set(tituloProyecto);
    }

    public StringProperty propiedadDescripcionProyecto() {
        if (descripcionProyecto == null) {
            descripcionProyecto = new SimpleStringProperty(this, "descripcionProyecto");
        }
        return descripcionProyecto;
    }

    public String getDescripcionProyecto() {
        return propiedadDescripcionProyecto().get();
    }

    public void setDescripcionProyecto(String descripcionProyecto) {
        propiedadDescripcionProyecto().set(descripcionProyecto);
    }

    public ListProperty<String> propiedadMiembrosProyecto() {
        if (miembrosProyecto == null) {
            miembrosProyecto = new SimpleListProperty<>(this, "miembrosProyecto");
        }
        return miembrosProyecto;
    }

    public ObservableList<String> getMiembrosProyecto() {
        return propiedadMiembrosProyecto().get();
    }

    public void setMiembrosProyecto(ObservableList<String> miembrosProyecto) {
        propiedadMiembrosProyecto().set(miembrosProyecto);
    }

    public void agregarMiembroProyecto(String miembroProyecto) {
        propiedadMiembrosProyecto().add(miembroProyecto);
    }

    public ListProperty<Tarea> propiedadTareasProyecto() {
        if (tareasProyecto == null) {
            tareasProyecto = new SimpleListProperty<>(this, "tareasProyecto");
        }
        return tareasProyecto;
    }

    public ObservableList<Tarea> getTareasProyecto() {
        return propiedadTareasProyecto().get();
    }

    public ObservableList<Tarea> getTareasIncompletasProyecto() {
        ObservableList<Tarea> tareasIncompletas = FXCollections.observableArrayList();
        tareasProyecto.stream()
                .filter(tarea -> !tarea.getCompletitudTarea())
                .forEach(tarea -> {
                    tareasIncompletas.add(tarea);
                });
        return tareasIncompletas;
    }

    public ObservableList<Tarea> getTareasCompletasProyecto() {
        ObservableList<Tarea> tareasCompletas = FXCollections.observableArrayList();
        tareasProyecto.stream()
                .filter(tarea -> tarea.getCompletitudTarea())
                .forEach(tarea -> {
                    tareasCompletas.add(tarea);
                });
        return tareasCompletas;
    }

    public void setTareasProyecto(ObservableList<Tarea> tareasProyecto) {
        propiedadTareasProyecto().set(tareasProyecto);
    }

    public void agregarTareaProyecto(Tarea tareaProyecto) {
        propiedadTareasProyecto().add(tareaProyecto);
    }

    public BooleanProperty propiedadCompletitudProyecto() {
        if (completitudProyecto == null) {
            completitudProyecto = new SimpleBooleanProperty(this, "completitudProyecto");
        }
        return completitudProyecto;
    }

    public boolean getCompletitudProyecto() {
        return propiedadCompletitudProyecto().get();
    }

    public void setCompletitudProyecto(boolean completitudProyecto) {
        propiedadCompletitudProyecto().set(completitudProyecto);
    }
}
