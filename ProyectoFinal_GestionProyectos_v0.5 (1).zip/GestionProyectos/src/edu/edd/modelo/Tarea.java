package edu.edd.modelo;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Tarea {
    
    private IntegerProperty idTarea;
    private StringProperty tituloTarea;
    private StringProperty descripcionTarea;
    private StringProperty responsableTarea;
    private BooleanProperty completitudTarea;
    
    public Tarea() {
    }
    
    public Tarea(int idTarea, String tituloTarea, String descripcionTarea,
            String responsableTarea, boolean completitudTarea) {
        inicializar(idTarea, tituloTarea, descripcionTarea, responsableTarea,
                completitudTarea);
    }
    
    private void inicializar(int idTarea, String tituloTarea, String descripcionTarea, String responsableTarea, boolean completitudTarea) {
        setIdTarea(idTarea);
        setTituloTarea(tituloTarea);
        setDescripcionTarea(descripcionTarea);
        setResponsableTarea(responsableTarea);
        setCompletitudTarea(completitudTarea);
    }
    
    public IntegerProperty propiedadIdTarea() {
        if (idTarea == null) {
            idTarea = new SimpleIntegerProperty(this, "idTarea");
        }
        return idTarea;
    }
    
    public int getIdTarea() {
        return propiedadIdTarea().get();
    }
    
    public void setIdTarea(int idTarea) {
        propiedadIdTarea().set(idTarea);
    }
    
    public StringProperty propiedadTituloTarea() {
        if (tituloTarea == null) {
            tituloTarea = new SimpleStringProperty(this, "tituloTarea");
        }
        return tituloTarea;
    }
    
    public String getTituloTarea() {
        return propiedadTituloTarea().get();
    }
    
    public void setTituloTarea(String tituloTarea) {
        propiedadTituloTarea().set(tituloTarea);
    }
    
    public StringProperty propiedadDescripcionTarea() {
        if (descripcionTarea == null) {
            descripcionTarea = new SimpleStringProperty(this, "descripcionTarea");
        }
        return descripcionTarea;
    }
    
    public String getDescripcionTarea() {
        return propiedadDescripcionTarea().get();
    }
    
    public void setDescripcionTarea(String descripcionTarea) {
        propiedadDescripcionTarea().set(descripcionTarea);
    }
    
    public StringProperty propiedadResponsableTarea() {
        if (responsableTarea == null) {
            responsableTarea = new SimpleStringProperty(this, "responsableTarea");
        }
        return responsableTarea;
    }
    
    public String getResponsableTarea() {
        return propiedadResponsableTarea().get();
    }
    
    public void setResponsableTarea(String responsableTarea) {
        propiedadResponsableTarea().set(responsableTarea);
    }
    
    public BooleanProperty propiedadCompletitudTarea() {
        if (completitudTarea == null) {
            completitudTarea = new SimpleBooleanProperty(this, "completitudTarea");
        }
        return completitudTarea;
    }
    
    public boolean getCompletitudTarea() {
        return propiedadCompletitudTarea().get();
    }
    
    public void setCompletitudTarea(boolean completitudTarea) {
        propiedadCompletitudTarea().set(completitudTarea);
    }
}
