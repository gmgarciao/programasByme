package edu.edd.modelo;

import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.collections.ObservableList;

public class Estudiante extends Usuario {

    private ListProperty<Proyecto> proyectosEstudiante;

    public Estudiante() {
    }

    public Estudiante(int idUsuario, String nombreUsuario,
            ObservableList<Proyecto> proyectosEstudiante) {
        super(idUsuario, nombreUsuario);
        inicializar(proyectosEstudiante);
    }

    private void inicializar(ObservableList<Proyecto> proyectosEstudiante) {
        setProyectosEstudiante(proyectosEstudiante);
    }

    public ListProperty<Proyecto> propiedadProyectosEstudiante() {
        if (proyectosEstudiante == null) {
            proyectosEstudiante = new SimpleListProperty<>(this, "proyectosEstudiante");
        }
        return proyectosEstudiante;
    }

    public ObservableList<Proyecto> getProyectosEstudiante() {
        return propiedadProyectosEstudiante().get();
    }

    public void setProyectosEstudiante(ObservableList<Proyecto> proyectosEstudiante) {
        propiedadProyectosEstudiante().set(proyectosEstudiante);
    }

    public void agregarProyectoEstudiante(Proyecto proyectoEstudiante) {
        propiedadProyectosEstudiante().add(proyectoEstudiante);
    }
}
