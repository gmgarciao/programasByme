package edu.edd.modelo;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Usuario {

    private IntegerProperty idUsuario;
    private StringProperty nombreUsuario;

    public Usuario() {
    }

    public Usuario(int idUsuario, String nombreUsuario) {
        inicializar(idUsuario, nombreUsuario);
    }
    
    private void inicializar(int idUsuario, String nombreUsuario) {
        setIdUsuario(idUsuario);
        setNombreUsuario(nombreUsuario);
    }

    public IntegerProperty propiedadIdUsuario() {
        if (idUsuario == null) {
            idUsuario = new SimpleIntegerProperty(this, "idUsuario");
        }
        return idUsuario;
    }

    public int getIdUsuario() {
        return propiedadIdUsuario().get();
    }

    public void setIdUsuario(int idUsuario) {
        propiedadIdUsuario().set(idUsuario);
    }

    public StringProperty propiedadNombreUsuario() {
        if (nombreUsuario == null) {
            nombreUsuario = new SimpleStringProperty(this, "tituloUsuario");
        }
        return nombreUsuario;
    }

    public String getNombreUsuario() {
        return propiedadNombreUsuario().get();
    }

    public void setNombreUsuario(String nombreUsuario) {
        propiedadNombreUsuario().set(nombreUsuario);
    }
}
