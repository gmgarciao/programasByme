package edu.edd.interfaz;

import java.util.List;
import java.util.Optional;

public interface OperadorPersistencia<T> {

    /**
     * Inserta la informacion de un objeto al registro correspondiente.
     *
     * @param objeto El objeto a registrar.
     * @return Verdadero en caso de que el registro sea exitoso. Falso en
     * cualquier otro caso.
     */
    public boolean insertarRegistro(T objeto);

    /**
     * Lee la informacion en el registro correspondiente.
     *
     * @return Una lista con todos los objetos obtenidos del registro.
     */
    public List<T> leerRegistros();

    /**
     *
     * @return El siguiente id en la serie del registro.
     */
    public int getIdSerial();

    /**
     *
     * @return El numero total de objetos registrados.
     */
    public int getTotalRegistros();

    /**
     *
     * @param id El id del objeto a eliminar dentro del registro.
     * @return Verdadero en caso de que la eliminacion sea exitosa. Falso en
     * cualquier otro caso.
     */
    public boolean eliminarRegistro(int id);

    /**
     * Cambia la informacion de un elemento del registro que comparte id con el
     * objeto dado.
     *
     * @param objeto Un objeto con la informacion actualizada.
     * @return Verdadero en caso de que la actualizacion sea exitosa. Falso en
     * cualquier otro caso.
     */
    public boolean actualizarRegistro(T objeto);

    /**
     * Lee la informacion en un elemento dentro del registro correspondiente.
     *
     * @param indice El indice del objeto a leer.
     * @return El objeto con la informacion leida.
     */
    public Optional<T> leerRegistro(int indice);

    /**
     * Lee la informacion de elementos dentro del registro correspondiente.
     *
     * @param indices Los indices de los objetos a leer.
     * @return Los objetos con la informacion leida.
     */
    public List<T> leerRegistros(List<Integer> indices);

    /**
     * Lee la informacion en un elemento dentro del registro correspondiente.
     *
     * @param id El id del objeto a leer.
     * @return El objeto con la informacion leida.
     */
    public Optional<T> leerRegistroPorId(int id);

    /**
     * Lee la informacion en los elementos dentro del registro correspondiente.
     *
     * @param ids Los ids de los objetos a leer.
     * @return Los objetos con la informacion leida.
     */
    public List<T> leerRegistrosPorId(List<Integer> ids);
}
