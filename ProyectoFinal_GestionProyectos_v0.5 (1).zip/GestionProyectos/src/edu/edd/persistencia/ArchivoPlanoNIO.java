package edu.edd.persistencia;

import edu.edd.recurso.dominio.Configuracion;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ArchivoPlanoNIO {

    private List<String> filas;
    private final Path miArchivo;
    private final String separadorFila;
    private final String separadorColumna;
    private final String finLinea = System.getProperty("line.separator");

    public ArchivoPlanoNIO(String nombreArchivo) throws IOException {
        this.separadorFila = "@";
        this.separadorColumna = Configuracion.SEPARADOR_COLUMNA;
        this.filas = new ArrayList<>();
        this.miArchivo = Paths.get(nombreArchivo, new String[0]);
        if (Files.exists(this.miArchivo)) {
            this.filas = this.obtenerContenidoArchivo();
        } else {
            this.crearArchivoVacio(nombreArchivo);
        }
    }

    public List<String> obtenerDatos() throws IOException {
        return this.filas;
    }

    public void agregarRegistro(String fila) throws IOException {
        ArrayList<String> listaLineas = new ArrayList<>();
        listaLineas.add(fila + this.separadorFila);
        Files.write(this.miArchivo, listaLineas, StandardOpenOption.APPEND);
    }

    public void resetar() throws IOException {
        Files.delete(this.miArchivo);
        Files.createFile(this.miArchivo, new FileAttribute[0]);
    }

    public String borrarFilaPosicion(int posicion) throws IOException {
        String filaEliminada = null;
        ArrayList<String> filasPersisten = new ArrayList<>();
        int limite = this.filas.size();
        for (int i = 0; i < limite; ++i) {
            String cadena = this.filas.get(i);
            if (posicion != i) {
                filasPersisten.add(cadena);
                continue;
            }
            filaEliminada = cadena;
        }
        this.resetar();
        Files.write(this.miArchivo, filasPersisten, StandardOpenOption.APPEND);
        return filaEliminada;
    }

    public boolean actualizaFilaPosicion(int posicion, String infoNueva) throws IOException {
        boolean correcto = false;
        ArrayList<String> filasPersisten = new ArrayList<>();
        int limite = this.filas.size();
        for (int i = 0; i < limite; ++i) {
            String cadena = this.filas.get(i);
            if (posicion != i) {
                filasPersisten.add(cadena);
                continue;
            }
            filasPersisten.add(infoNueva + this.separadorFila);
            correcto = true;
        }
        this.resetar();
        Files.write(this.miArchivo, filasPersisten, StandardOpenOption.APPEND);
        return correcto;
    }

    public int ultimoCodigo() throws IOException {
        int codigo = 0;
        for (String cadena : this.filas) {
            int desde = 0;
            int cuente = cadena.indexOf(this.separadorColumna, desde);
            codigo = Integer.parseInt(cadena.substring(desde, cuente).trim());
        }
        return codigo;
    }

    public String obtenerFila(int indice) throws IndexOutOfBoundsException {
        return filas.get(indice);
    }

    public List<String> obtenerFilas(List<Integer> indices) {
        int it = 0;
        List<String> filasEncontradas = new ArrayList<>(indices.size());
        for (String fila : this.filas) {
            if (indices.contains(it)) {
                filasEncontradas.add(fila);
            }
            ++it;
        }
        return filasEncontradas;
    }

    public int cantidadFilas() throws IOException {
        return this.filas.size();
    }

    public static List<String> listaArchivos(String directorio) {
        ArrayList<String> arrNombresArchivos = new ArrayList<>();
        try (DirectoryStream<Path> directorioStream = Files
                .newDirectoryStream(Paths.get(directorio));) {
            for (Path path : directorioStream) {
                arrNombresArchivos.add(path.toString());
            }
        } catch (IOException iOException) {
            // empty catch block
        }
        return arrNombresArchivos;
    }

    private void crearArchivoVacio(String nombreArchivo) {
        try {
            Files.createFile(this.miArchivo, new FileAttribute[0]);
            System.out.println("***********************************************");
            System.out.println("Archivo " + nombreArchivo + " no existe, creado con NIO");
            System.out.println("***********************************************");
        } catch (IOException ex) {
            System.out.println("***********************************************");
            System.out.println("No existe la RUTA " + nombreArchivo);
            System.out.println("***********************************************");
            Logger.getLogger(ArchivoPlanoNIO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private List<String> obtenerContenidoArchivo() {
        List<String> arrTemporal = new ArrayList<>();
        try {
            if (Files.size(this.miArchivo) > 0L) {
                String contenido = Files.readString(this.miArchivo, StandardCharsets.UTF_8);
                String[] lineasContenido = contenido.split(this.separadorFila);
                arrTemporal = this.quitarFilasVacias(lineasContenido);
            }
        } catch (IOException ex) {
            Logger.getLogger(ArchivoPlanoNIO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return arrTemporal;
    }

    private List<String> quitarFilasVacias(String[] filasTotales) {
        int limite = filasTotales.length;
        ArrayList<String> filasDepuradas = new ArrayList<>();
        for (int i = 0; i < limite; ++i) {
            if (filasTotales[i].equals(this.finLinea)) {
                continue;
            }
            String fila = filasTotales[i];
            String saltoLinea = fila.substring(0, 2);
            if (saltoLinea.equals(this.finLinea)) {
                fila = fila.substring(2, fila.length());
            }
            filasDepuradas.add(fila + this.separadorFila);
        }
        return filasDepuradas;
    }
}
