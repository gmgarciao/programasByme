package edu.edd.persistencia;

import edu.edd.controlador.ControladorProyecto;
import edu.edd.interfaz.OperadorPersistencia;
import edu.edd.modelo.Estudiante;
import edu.edd.modelo.Proyecto;
import edu.edd.modelo.Usuario;
import edu.edd.recurso.dominio.Configuracion;
import edu.edd.recurso.dominio.Ruta;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;

public class DaoUsuario implements OperadorPersistencia<Usuario> {

    private ArchivoPlanoNIO archivoPersistencia;
    private final String rutaPersistencia;

    public DaoUsuario() {
        rutaPersistencia = Ruta.RUTA_PERSISTENCIA
                + Configuracion.SEPARADOR_DIRECTORIOS
                + Configuracion.ARCHIVO_USUARIOS;
        try {
            archivoPersistencia = new ArchivoPlanoNIO(rutaPersistencia);
        } catch (IOException ex) {
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // *************************************************************************
    // Funciones asistentes
    // *************************************************************************
    private Optional<Integer> getIndiceConId(int id) {
        try {
            int indice = 0;
            List<String> registros = archivoPersistencia.obtenerDatos();
            for (String registro : registros) {
                Integer idRegistro = Integer.valueOf(registro.substring(0,
                        registro.indexOf(Configuracion.SEPARADOR_COLUMNA)));
                if (id == idRegistro) {
                    return Optional.of(indice);
                }
                indice++;
            }
        } catch (IOException ex) {
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Optional.empty();
    }

    private String getRegistroLista(List<String> lista) {
        String registro = "";
        for (String string : lista) {
            if (!string.isBlank()) {
                registro += string.trim() + Configuracion.SEPARADOR_COLUMNA;
            }
        }
        if (registro.endsWith(Configuracion.SEPARADOR_COLUMNA)) {
            registro = registro.substring(0, registro.length() - 1);
        }
        return registro;
    }

    private List<String> parseRegistroLista(String registroLista) {
        String[] items = registroLista.split(Configuracion.SEPARADOR_COLUMNA);
        List<String> lista = new ArrayList<>(items.length);
        for (String item : items) {
            lista.add(item.trim());
        }

        return lista;
    }

    private String getRegistroUsuario(Usuario usuario) {
        String tipoUsuario = usuario.getClass().getSimpleName();
        String registro = Integer.toString(usuario.getIdUsuario())
                + Configuracion.SEPARADOR_COLUMNA
                + tipoUsuario
                + Configuracion.SEPARADOR_COLUMNA
                + usuario.getNombreUsuario();
        if (tipoUsuario.equals(Estudiante.class.getSimpleName())) {
            List<String> arregloIdsProyectos = new LinkedList<>();
            Estudiante estudiante = (Estudiante) usuario;
            for (Proyecto proyecto : estudiante.getProyectosEstudiante()) {
                arregloIdsProyectos.add(Integer.toString(proyecto.getIdProyecto()));
            }
            registro += Configuracion.SEPARADOR_COLUMNA
                    + Configuracion.INDICADOR_INICIO_LISTA
                    + getRegistroLista(arregloIdsProyectos)
                    + Configuracion.INDICADOR_FIN_LISTA;
        }
        return registro;
    }

    private Optional<Usuario> parseRegistroUsuario(String registroUsuario) {
        if (registroUsuario.isBlank()) {
            return Optional.empty();
        }
        int desde = 0;
        int hasta = registroUsuario.indexOf(Configuracion.SEPARADOR_COLUMNA, desde);
        int idUsuario = Integer.parseInt(registroUsuario.substring(desde, hasta).trim());

        desde = hasta + 1;
        hasta = registroUsuario.indexOf(Configuracion.SEPARADOR_COLUMNA, desde);
        String tipoUsuario = registroUsuario.substring(desde, hasta).trim();

        if (tipoUsuario.equals(Estudiante.class.getSimpleName())) {
            desde = hasta + 1;
            hasta = registroUsuario.indexOf(Configuracion.SEPARADOR_COLUMNA, desde);
            String nombreUsuario = registroUsuario.substring(desde, hasta).trim();

            desde = registroUsuario.indexOf(Configuracion.INDICADOR_INICIO_LISTA, desde) + 1;
            hasta = registroUsuario.indexOf(Configuracion.INDICADOR_FIN_LISTA, desde);
            List<String> arregloIdsCadenas = parseRegistroLista(registroUsuario.substring(desde, hasta));
            List<Integer> arregloIds = new ArrayList<>(arregloIdsCadenas.size());
            arregloIdsCadenas.forEach((idString) -> {
                if (!idString.isBlank()) {
                    int id = Integer.parseInt(idString);
                    arregloIds.add(id);
                }
            });
            List<Proyecto> proyectosEstudiante = ControladorProyecto.obtenerProyectosPorId(arregloIds);
            return Optional.of(new Estudiante(idUsuario, nombreUsuario,
                    FXCollections.observableList(proyectosEstudiante)));
        } else {
            desde = hasta + 1;
            hasta = registroUsuario.length() - 1;
            String nombreUsuario = registroUsuario.substring(desde, hasta).trim();
            return Optional.of(new Usuario(idUsuario, nombreUsuario));
        }
    }

    // *************************************************************************
    // Operaciones de I/O
    // *************************************************************************
    @Override
    public boolean insertarRegistro(Usuario objeto) {
        boolean correcto = false;
        String fila = getRegistroUsuario(objeto);
        try {
            archivoPersistencia.agregarRegistro(fila);
            correcto = true;
        } catch (IOException ex) {
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return correcto;
    }

    @Override
    public List<Usuario> leerRegistros() {
        String fila;
        int limite = getTotalRegistros();
        List<String> arregloDatos;
        List<Usuario> arregloUsuarios = new ArrayList<>(limite);
        try {
            arregloDatos = archivoPersistencia.obtenerDatos();
            for (int i = 0; i < limite; i++) {
                fila = arregloDatos.get(i);
                Usuario usuario = parseRegistroUsuario(fila).orElseThrow();
                if (usuario != null) {
                    arregloUsuarios.add(usuario);
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return arregloUsuarios;
    }

    @Override
    public int getIdSerial() {
        int id = 0;
        try {
            id = archivoPersistencia.ultimoCodigo();
        } catch (IOException ex) {
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id + 1;
    }

    @Override
    public int getTotalRegistros() {
        int cantidad = 0;
        try {
            cantidad = archivoPersistencia.cantidadFilas();
        } catch (IOException ex) {
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cantidad;
    }

    @Override
    public boolean eliminarRegistro(int id) {
        boolean correcto = false;
        try {
            int indice = getIndiceConId(id).orElseThrow();
            correcto = !archivoPersistencia.borrarFilaPosicion(indice).isBlank();
        } catch (IOException ex) {
            Logger.getLogger(DaoTarea.class.getName()).log(Level.SEVERE, null, ex);
        }
        return correcto;
    }

    @Override
    public boolean actualizarRegistro(Usuario objeto) {
        boolean correcto = false;
        try {
            int indice = getIndiceConId(objeto.getIdUsuario()).orElseThrow();
            String registro = getRegistroUsuario(objeto);
            correcto = archivoPersistencia.actualizaFilaPosicion(indice, registro);
        } catch (IOException ex) {
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return correcto;
    }

    @Override
    public Optional<Usuario> leerRegistro(int indice) {
        String registro = archivoPersistencia.obtenerFila(indice);
        return parseRegistroUsuario(registro);
    }

    @Override
    public List<Usuario> leerRegistros(List<Integer> indices) {
        List<Usuario> usuarios = new ArrayList<>(indices.size());
        List<String> registros = archivoPersistencia.obtenerFilas(indices);
        for (String registro : registros) {
            usuarios.add(parseRegistroUsuario(registro).orElseThrow());
        }
        return usuarios;
    }

    @Override
    public Optional<Usuario> leerRegistroPorId(int id) {
        int indice = getIndiceConId(id).orElseThrow();
        return leerRegistro(indice);
    }

    @Override
    public List<Usuario> leerRegistrosPorId(List<Integer> ids) {
        List<Usuario> usuarios = new ArrayList<>(ids.size());
        List<String> registros;
        try {
            registros = archivoPersistencia.obtenerDatos();
            for (String registro : registros) {
                Integer idRegistro = Integer.valueOf(registro.substring(0,
                        registro.indexOf(Configuracion.SEPARADOR_COLUMNA)));
                if (ids.contains(idRegistro)) {
                    usuarios.add(parseRegistroUsuario(registro).orElseThrow());
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(DaoUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return usuarios;
    }
}
