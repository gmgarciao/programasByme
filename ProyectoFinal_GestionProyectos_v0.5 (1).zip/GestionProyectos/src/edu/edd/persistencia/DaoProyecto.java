package edu.edd.persistencia;

import edu.edd.controlador.ControladorTarea;
import edu.edd.interfaz.OperadorPersistencia;
import edu.edd.modelo.Proyecto;
import edu.edd.modelo.Tarea;
import edu.edd.recurso.dominio.Configuracion;
import edu.edd.recurso.dominio.Ruta;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;

/**
 * Provee la implementacion del operador de la persistencia para Proyectos.
 */
public class DaoProyecto implements OperadorPersistencia<Proyecto> {

    private ArchivoPlanoNIO archivoPersistencia;
    private String rutaPersistencia;

    public DaoProyecto() {
        rutaPersistencia = Ruta.RUTA_PERSISTENCIA
                + Configuracion.SEPARADOR_DIRECTORIOS
                + Configuracion.ARCHIVO_PROYECTOS;
        try {
            archivoPersistencia = new ArchivoPlanoNIO(rutaPersistencia);
        } catch (IOException ex) {
            Logger.getLogger(DaoProyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // *************************************************************************
    // Funciones asistentes
    // *************************************************************************
    
    private Optional<Integer> getIndiceConId(int id) {
        try {
            int indice = 0;
            List<String> registros = archivoPersistencia.obtenerDatos();
            for (String registro : registros) {
                Integer idRegistro = Integer.valueOf(registro.substring(0,
                        registro.indexOf(Configuracion.SEPARADOR_COLUMNA)).trim());
                if (id == idRegistro) {
                    return Optional.of(indice);
                }
                indice++;
            }
        } catch (IOException ex) {
            Logger.getLogger(DaoProyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Optional.empty();
    }

    private String getRegistroLista(List<String> lista) {
        String registro = "";
        for (String string : lista) {
            if (!string.isBlank()) {
                registro += string.trim() + Configuracion.SEPARADOR_COLUMNA;
            }
        }
        if (registro.endsWith(Configuracion.SEPARADOR_COLUMNA)) {
            registro = registro.substring(0, registro.length() - 1);
        }
        return registro;
    }

    private List<String> parseRegistroLista(String registroLista) {
        String[] items = registroLista.split(Configuracion.SEPARADOR_COLUMNA);
        List<String> lista = new ArrayList<>(items.length);
        for (String item : items) {
            lista.add(item.trim());
        }

        return lista;
    }

    private String getRegistroProyecto(Proyecto proyecto) {
        String registroMiembros = getRegistroLista(proyecto.getMiembrosProyecto());
        List<String> arregloIdsTareas = new ArrayList<>();
        for (Tarea tarea : proyecto.getTareasProyecto()) {
            arregloIdsTareas.add(Integer.toString(tarea.getIdTarea()));
        }
        return Integer.toString(proyecto.getIdProyecto())
                + Configuracion.SEPARADOR_COLUMNA
                + proyecto.getTituloProyecto()
                + Configuracion.SEPARADOR_COLUMNA
                + proyecto.getDescripcionProyecto()
                + Configuracion.SEPARADOR_COLUMNA
                + Configuracion.INDICADOR_INICIO_LISTA
                + registroMiembros
                + Configuracion.INDICADOR_FIN_LISTA
                + Configuracion.SEPARADOR_COLUMNA
                + Configuracion.INDICADOR_INICIO_LISTA
                + getRegistroLista(arregloIdsTareas)
                + Configuracion.INDICADOR_FIN_LISTA
                + Configuracion.SEPARADOR_COLUMNA
                + Boolean.toString(proyecto.getCompletitudProyecto());
    }

    private Optional<Proyecto> parseRegistroProyecto(String registroProyecto) {
        if (registroProyecto.isBlank()) {
            return Optional.empty();
        }
        int desde = 0;
        int hasta = registroProyecto.indexOf(Configuracion.SEPARADOR_COLUMNA);
        int idProyecto = Integer.parseInt(registroProyecto.substring(desde, hasta).trim());

        desde = hasta + 1;
        hasta = registroProyecto.indexOf(Configuracion.SEPARADOR_COLUMNA, desde);
        String tituloProyecto = registroProyecto.substring(desde, hasta).trim();

        desde = hasta + 1;
        hasta = registroProyecto.indexOf(Configuracion.SEPARADOR_COLUMNA, desde);
        String descripcionProyecto = registroProyecto.substring(desde, hasta).trim();

        desde = registroProyecto.indexOf(Configuracion.INDICADOR_INICIO_LISTA, desde) + 1;
        hasta = registroProyecto.indexOf(Configuracion.INDICADOR_FIN_LISTA, desde);
        List<String> miembrosProyecto = parseRegistroLista(registroProyecto.substring(desde, hasta));

        desde = registroProyecto.indexOf(Configuracion.INDICADOR_INICIO_LISTA, hasta + 2) + 1;
        hasta = registroProyecto.indexOf(Configuracion.INDICADOR_FIN_LISTA, desde);
        List<String> arregloIdsTareas = parseRegistroLista(registroProyecto.substring(desde, hasta));
        List<Tarea> tareasProyecto = new LinkedList<>();
        arregloIdsTareas.forEach((idString) -> {
            if (!idString.isBlank()) {
                int id = Integer.parseInt(idString);
                tareasProyecto.add(ControladorTarea.obtenerTareaPorId(id).orElseThrow());
            }
        });

        desde = hasta + 2;
        hasta = registroProyecto.length() - 1;
        boolean completitudProyecto = Boolean.parseBoolean(registroProyecto.substring(desde, hasta));

        return Optional.of(new Proyecto(idProyecto, tituloProyecto,
                descripcionProyecto, FXCollections.observableList(miembrosProyecto),
                FXCollections.observableList(tareasProyecto), completitudProyecto));
    }

    // *************************************************************************
    // Operaciones de I/O
    // *************************************************************************
    
    @Override
    public boolean insertarRegistro(Proyecto objeto) {
        boolean correcto = false;
        try {
            String registro = getRegistroProyecto(objeto);
            archivoPersistencia.agregarRegistro(registro);
            correcto = true;
        } catch (IOException ex) {
            Logger.getLogger(DaoProyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return correcto;
    }

    @Override
    public List<Proyecto> leerRegistros() {
        String fila;
        int limite = getTotalRegistros();
        List<String> arregloDatos;
        List<Proyecto> arregloProyectos = new ArrayList<>(limite);
        try {
            arregloDatos = archivoPersistencia.obtenerDatos();
            for (int i = 0; i < limite; i++) {
                fila = arregloDatos.get(i);
                Proyecto proyecto = parseRegistroProyecto(fila).orElseThrow();
                if (proyecto != null) {
                    arregloProyectos.add(proyecto);
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(DaoProyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return arregloProyectos;
    }

    @Override
    public int getIdSerial() {
        int id = 0;
        try {
            id = archivoPersistencia.ultimoCodigo();
        } catch (IOException ex) {
            Logger.getLogger(DaoProyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id + 1;
    }

    @Override
    public int getTotalRegistros() {
        int cantidad = 0;
        try {
            cantidad = archivoPersistencia.cantidadFilas();
        } catch (IOException ex) {
            Logger.getLogger(DaoProyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cantidad;
    }

    @Override
    public boolean eliminarRegistro(int id) {
        boolean correcto = false;
        try {
            int indice = getIndiceConId(id).orElseThrow();
            correcto = !archivoPersistencia.borrarFilaPosicion(indice).isBlank();
        } catch (IOException ex) {
            Logger.getLogger(DaoTarea.class.getName()).log(Level.SEVERE, null, ex);
        }
        return correcto;
    }

    @Override
    public boolean actualizarRegistro(Proyecto objeto) {
        boolean correcto = false;
        try {
            int indice = getIndiceConId(objeto.getIdProyecto()).orElseThrow();
            String registro = getRegistroProyecto(objeto);
            correcto = archivoPersistencia.actualizaFilaPosicion(indice, registro);
        } catch (IOException ex) {
            Logger.getLogger(DaoProyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return correcto;
    }

    @Override
    public Optional<Proyecto> leerRegistro(int indice) {
        String registro = archivoPersistencia.obtenerFila(indice);
        return parseRegistroProyecto(registro);
    }

    @Override
    public List<Proyecto> leerRegistros(List<Integer> indices) {
        List<Proyecto> proyectos = new ArrayList<>(indices.size());
        List<String> registros = archivoPersistencia.obtenerFilas(indices);
        for (String registro : registros) {
            proyectos.add(parseRegistroProyecto(registro).orElseThrow());
        }
        return proyectos;
    }

    @Override
    public Optional<Proyecto> leerRegistroPorId(int id) {
        int indice = getIndiceConId(id).orElseThrow();
        return leerRegistro(indice);
    }

    @Override
    public List<Proyecto> leerRegistrosPorId(List<Integer> ids) {
        List<Proyecto> proyectos = new ArrayList<>(ids.size());
        List<String> registros;
        try {
            registros = archivoPersistencia.obtenerDatos();
            for (String registro : registros) {
                Integer idRegistro = Integer.valueOf(registro.substring(0,
                        registro.indexOf(Configuracion.SEPARADOR_COLUMNA)).trim());
                if (ids.contains(idRegistro)) {
                    proyectos.add(parseRegistroProyecto(registro).orElseThrow());
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(DaoProyecto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return proyectos;
    }
}
