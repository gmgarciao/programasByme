package edu.edd.persistencia;

import edu.edd.interfaz.OperadorPersistencia;
import edu.edd.modelo.Tarea;
import edu.edd.recurso.dominio.Configuracion;
import edu.edd.recurso.dominio.Ruta;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Provee la implementacion del operador de la persistencia para Tareas.
 */
public class DaoTarea implements OperadorPersistencia<Tarea> {

    private ArchivoPlanoNIO archivoPersistencia;
    private String rutaPersistencia;

    public DaoTarea() {
        rutaPersistencia = Ruta.RUTA_PERSISTENCIA
                + Configuracion.SEPARADOR_DIRECTORIOS
                + Configuracion.ARCHIVO_TAREAS;
        try {
            archivoPersistencia = new ArchivoPlanoNIO(rutaPersistencia);
        } catch (IOException ex) {
            Logger.getLogger(DaoTarea.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // *************************************************************************
    // Funciones asistentes
    // *************************************************************************
    
    private Optional<Integer> getIndiceConId(int id) {
        try {
            int indice = 0;
            List<String> registros = archivoPersistencia.obtenerDatos();
            for (String registro : registros) {
                Integer idRegistro = Integer.valueOf(registro.substring(0,
                        registro.indexOf(Configuracion.SEPARADOR_COLUMNA)).trim());
                if (id == idRegistro) {
                    return Optional.of(indice);
                }
                indice++;
            }
        } catch (IOException ex) {
            Logger.getLogger(DaoTarea.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Optional.empty();
    }

    private String getRegistroTarea(Tarea tarea) {
        return Integer.toString(tarea.getIdTarea())
                + Configuracion.SEPARADOR_COLUMNA
                + tarea.getTituloTarea()
                + Configuracion.SEPARADOR_COLUMNA
                + tarea.getDescripcionTarea()
                + Configuracion.SEPARADOR_COLUMNA
                + tarea.getResponsableTarea()
                + Configuracion.SEPARADOR_COLUMNA
                + Boolean.toString(tarea.getCompletitudTarea());
    }

    private Optional<Tarea> parseRegistroTarea(String registroTarea) {
        if (registroTarea.isBlank()) {
            return Optional.empty();
        }
        int desde = 0;
        int hasta = registroTarea.indexOf(Configuracion.SEPARADOR_COLUMNA, desde);
        int idTarea = Integer.parseInt(registroTarea.substring(desde, hasta).trim());

        desde = hasta + 1;
        hasta = registroTarea.indexOf(Configuracion.SEPARADOR_COLUMNA, desde);
        String tituloTarea = registroTarea.substring(desde, hasta).trim();

        desde = hasta + 1;
        hasta = registroTarea.indexOf(Configuracion.SEPARADOR_COLUMNA, desde);
        String descripcionTarea = registroTarea.substring(desde, hasta).trim();

        desde = hasta + 1;
        hasta = registroTarea.indexOf(Configuracion.SEPARADOR_COLUMNA, desde);
        String responsableTarea = registroTarea.substring(desde, hasta).trim();

        desde = hasta + 1;
        hasta = registroTarea.length() - 1;
        boolean completitudTarea = Boolean.parseBoolean(registroTarea.substring(desde, hasta));

        return Optional.of(new Tarea(idTarea, tituloTarea, descripcionTarea,
                responsableTarea, completitudTarea));
    }
    
    // *************************************************************************
    // Operaciones de I/O
    // *************************************************************************

    @Override
    public boolean insertarRegistro(Tarea objeto) {
        boolean correcto = false;
        try {
            String registro = getRegistroTarea(objeto);
            archivoPersistencia.agregarRegistro(registro);
            correcto = true;
        } catch (IOException ex) {
            Logger.getLogger(DaoTarea.class.getName()).log(Level.SEVERE, null, ex);
        }
        return correcto;
    }

    @Override
    public List<Tarea> leerRegistros() {
        String fila;
        int limite = getTotalRegistros();
        List<String> arregloDatos;
        List<Tarea> arregloTareas = new ArrayList<>(limite);
        try {
            arregloDatos = archivoPersistencia.obtenerDatos();
            for (int i = 0; i < limite; i++) {
                fila = arregloDatos.get(i);
                Tarea tarea = parseRegistroTarea(fila).orElseThrow();

                arregloTareas.add(tarea);
            }
        } catch (IOException ex) {
            Logger.getLogger(DaoTarea.class.getName()).log(Level.SEVERE, null, ex);
        }
        return arregloTareas;
    }

    @Override
    public int getIdSerial() {
        int id = 0;
        try {
            id = archivoPersistencia.ultimoCodigo();
        } catch (IOException ex) {
            Logger.getLogger(DaoTarea.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id + 1;
    }

    @Override
    public int getTotalRegistros() {
        int cantidad = 0;
        try {
            cantidad = archivoPersistencia.cantidadFilas();
        } catch (IOException ex) {
            Logger.getLogger(DaoTarea.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cantidad;
    }

    @Override
    public boolean eliminarRegistro(int id) {
        boolean correcto = false;
        try {
            int indice = getIndiceConId(id).orElseThrow();
            correcto = !archivoPersistencia.borrarFilaPosicion(indice).isBlank();
        } catch (IOException ex) {
            Logger.getLogger(DaoTarea.class.getName()).log(Level.SEVERE, null, ex);
        }
        return correcto;
    }

    @Override
    public boolean actualizarRegistro(Tarea objeto) {
        boolean correcto = false;
        try {
            int indice = getIndiceConId(objeto.getIdTarea()).orElseThrow();
            String registro = getRegistroTarea(objeto);
            correcto = archivoPersistencia.actualizaFilaPosicion(indice, registro);
        } catch (IOException ex) {
            Logger.getLogger(DaoTarea.class.getName()).log(Level.SEVERE, null, ex);
        }
        return correcto;
    }

    @Override
    public Optional<Tarea> leerRegistro(int indice) {
        String registro = archivoPersistencia.obtenerFila(indice);
        return parseRegistroTarea(registro);
    }

    @Override
    public List<Tarea> leerRegistros(List<Integer> indices) {
        List<Tarea> tareas = new ArrayList<>(indices.size());
        List<String> registros = archivoPersistencia.obtenerFilas(indices);
        for (String registro : registros) {
            tareas.add(parseRegistroTarea(registro).orElseThrow());
        }
        return tareas;
    }

    @Override
    public Optional<Tarea> leerRegistroPorId(int id) {
        int indice = getIndiceConId(id).orElseThrow();
        return leerRegistro(indice);
    }

    @Override
    public List<Tarea> leerRegistrosPorId(List<Integer> ids) {
        List<Tarea> tareas = new ArrayList<>(ids.size());
        List<String> registros;
        try {
            registros = archivoPersistencia.obtenerDatos();
            for (String registro : registros) {
                Integer idRegistro = Integer.valueOf(registro.substring(0,
                        registro.indexOf(Configuracion.SEPARADOR_COLUMNA)));
                if (ids.contains(idRegistro)) {
                    tareas.add(parseRegistroTarea(registro).orElseThrow());
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(DaoTarea.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tareas;
    }
}
