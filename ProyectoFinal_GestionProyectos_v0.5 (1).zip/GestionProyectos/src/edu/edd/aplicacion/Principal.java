package edu.edd.aplicacion;

import edu.edd.vista.VistaPrincipal;
import javafx.application.Application;
import javafx.stage.Stage;

public class Principal extends Application {

    public Principal() {
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage escenario) throws Exception {
        new VistaPrincipal(escenario);
        escenario.setResizable(false);
        escenario.show();
    }

}
