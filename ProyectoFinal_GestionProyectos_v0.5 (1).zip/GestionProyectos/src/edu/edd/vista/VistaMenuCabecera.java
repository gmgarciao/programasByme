package edu.edd.vista;

import edu.edd.controlador.ControladorVistas;
import edu.edd.modelo.Estudiante;
import edu.edd.modelo.Usuario;
import javafx.scene.SubScene;
import javafx.scene.control.Button;
import javafx.scene.control.Separator;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class VistaMenuCabecera extends SubScene {

    private final HBox contenedor;
    private final BorderPane panelPrimario;
    private Pane panelCentral;
    private Usuario usuario;

    public VistaMenuCabecera(Usuario usuario, BorderPane panelPrimario, Pane panelCentral,
            double ancho, double alto) {
        super(new HBox(), ancho, alto);
        contenedor = (HBox) getRoot();

        this.usuario = usuario;
        this.panelPrimario = panelPrimario;
        this.panelCentral = panelCentral;

        organizar(ancho, alto);
    }

    public HBox getContenedor() {
        return contenedor;
    }

    private void organizar(double ancho, double alto) {
        ToolBar barra = new ToolBar();
        barra.setPrefWidth(ancho);

        Button botonVerProyectos = new Button("Proyectos");
        botonVerProyectos.setOnAction(e -> {
            e.consume();
            panelCentral = ControladorVistas.verProyectos(usuario, panelPrimario,
                    panelCentral, ancho, alto);
            panelPrimario.setCenter(null);
            panelPrimario.setCenter(panelCentral);
        });
        
        if (Estudiante.class.equals(usuario.getClass())) {
            
        }

        Button botonExplorarProyectos = new Button("Explorar Proyectos");
        botonExplorarProyectos.setOnAction(e -> {
            e.consume();
            panelCentral = ControladorVistas.buscarProyectos(usuario, ancho, alto);
            panelPrimario.setCenter(null);
            panelPrimario.setCenter(panelCentral);
        });

        Button botonAcerca = new Button("?");
        botonAcerca.setOnAction(e -> {
            e.consume();
            Stage ventanaAcerca = ControladorVistas.verAcerca();
            ventanaAcerca.show();
        });

        barra.getItems().addAll(botonVerProyectos, botonExplorarProyectos,
                new Separator(), botonAcerca);
        contenedor.getChildren().add(barra);
    }

}
