package edu.edd.vista.tarea;

import edu.edd.controlador.ControladorProyecto;
import edu.edd.controlador.ControladorTarea;
import edu.edd.controlador.ControladorVistas;
import edu.edd.modelo.Proyecto;
import edu.edd.modelo.Tarea;
import edu.edd.modelo.Usuario;
import edu.edd.recurso.dominio.Contenedor;
import java.util.Optional;
import java.util.stream.IntStream;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.SubScene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Modality;

public class VistaEditarTarea extends SubScene {

    private final VBox contenedor;
    private final GridPane formulario;
    private final BorderPane panelPrimario;
    private Pane panelCentral;

    private final Usuario usuario;
    private final Proyecto proyecto;
    private final Tarea tarea;
    private final ObservableList<String> miembros;

    public VistaEditarTarea(Usuario usuario, Proyecto proyecto, Tarea tarea,
            BorderPane panelPrimario, Pane panelCentral, double ancho, double alto) {
        super(new VBox(), ancho, alto);
        this.usuario = usuario;
        this.proyecto = proyecto;
        this.tarea = tarea;
        this.panelPrimario = panelPrimario;
        this.panelCentral = panelCentral;
        contenedor = (VBox) getRoot();
        miembros = proyecto.getMiembrosProyecto();

        double anchoFormulario = ancho * 0.8;
        formulario = new GridPane();

        contenedor.setPadding(new Insets(20));
        contenedor.getChildren().add(formulario);

        construirFormulario(anchoFormulario);
    }

    public VBox getContenedor() {
        return contenedor;
    }

    private void construirFormulario(double ancho) {
        formulario.setPrefWidth(ancho);
        formulario.setAlignment(Pos.TOP_CENTER);
        formulario.setHgap(10);
        formulario.setVgap(10);

        double columna1 = ancho * 0.4;
        double columna2 = ancho * 0.55;

        formulario.getColumnConstraints().addAll(new ColumnConstraints(columna1),
                new ColumnConstraints(columna2));

        Label titulo = new Label("Editar Tarea");
        titulo.setFont(new Font(24));

        formulario.add(titulo, 0, 0, 2, 1);

        Label labelTituloTarea = new Label("Titulo Tarea:");
        TextField campoTituloTarea = new TextField(tarea.getTituloTarea().trim());

        formulario.add(labelTituloTarea, 0, 1);
        formulario.add(campoTituloTarea, 1, 1);

        Label labelDescripcionTarea = new Label("Descripcion:");
        TextArea campoDescripcionTarea = new TextArea(tarea.getDescripcionTarea().trim());
        campoDescripcionTarea.setWrapText(true);

        formulario.add(labelDescripcionTarea, 0, 2);
        formulario.add(campoDescripcionTarea, 1, 2);

        Label labelResponsable = new Label("Miembro responsable:");
        ComboBox<String> seleccionMiembro = new ComboBox<>(miembros);
        seleccionMiembro.setValue(tarea.getResponsableTarea());

        formulario.add(labelResponsable, 0, 3);
        formulario.add(seleccionMiembro, 1, 3);

        CheckBox fueCompletada = new CheckBox("Completada");
        fueCompletada.setSelected(tarea.getCompletitudTarea());

        formulario.add(fueCompletada, 1, 4);

        Button botonEnviar = new Button("Guardar Cambios");
        botonEnviar.setOnAction(e -> {
            String tituloTarea = campoTituloTarea.getText().trim();
            String descripcionTarea = campoDescripcionTarea.getText().trim();
            String responsableTarea = seleccionMiembro.getValue();
            if (responsableTarea != null) {
                boolean completitudTarea = fueCompletada.isSelected();
                Optional<Tarea> tareaActualizada = ControladorTarea.actualizar(tarea, tituloTarea, descripcionTarea, responsableTarea, completitudTarea);
                if (tareaActualizada.isPresent()) {
                    ObservableList<Tarea> tareasProyecto = proyecto.getTareasProyecto();
                    Tarea nuevaTarea = tareaActualizada.get();
                    int index = IntStream.range(0, tareasProyecto.size())
                            .filter(i -> tareasProyecto.get(i).getIdTarea() == nuevaTarea.getIdTarea())
                            .findFirst()
                            .orElseThrow();

                    tareasProyecto.set(index, nuevaTarea);
                    proyecto.setTareasProyecto(tareasProyecto);

                    Proyecto proyectoActualizado = ControladorProyecto.actualizar(proyecto).get();
                    panelCentral = ControladorVistas.manejarTareas(usuario, proyectoActualizado,
                            panelPrimario, panelCentral, ancho, ancho);

                    panelPrimario.setCenter(null);
                    panelPrimario.setCenter(panelCentral);
                } else {
                    Alert mensaje = new Alert(Alert.AlertType.ERROR,
                            "Por favor revise la información.", ButtonType.CLOSE);
                    mensaje.initModality(Modality.APPLICATION_MODAL);
                    mensaje.show();
                }
            }
        });

        Button botonCancelar = new Button("Cancelar");
        botonCancelar.setOnAction(e -> {
            panelCentral = ControladorVistas.manejarTareas(usuario, proyecto, panelPrimario, panelCentral,
                    Contenedor.CUERPO.getAncho(), Contenedor.CUERPO.getAlto());
            panelPrimario.setCenter(null);
            panelPrimario.setCenter(panelCentral);
        });

        formulario.add(new HBox(12, botonCancelar, botonEnviar), 0, 5, 2, 1);
    }

}
