package edu.edd.vista.acerca;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class VistaAcerca {

    private final Stage escenario;
    private final Scene escena;

    private final VBox contenedor;

    public VistaAcerca(double ancho, double alto) {
        escenario = new Stage();
        contenedor = new VBox(12);

        organizar();

        escena = new Scene(contenedor, ancho, alto);
        escenario.setScene(escena);
    }

    public Stage getEscenario() {
        return escenario;
    }

    private void organizar() {
        contenedor.setPadding(new Insets(20));
        contenedor.setAlignment(Pos.CENTER_LEFT);
        
        Label nombrePrograma = new Label("Programa de Gestion de Proyectos");
        nombrePrograma.setFont(Font.font(24));
        nombrePrograma.setWrapText(true);
        
        Label cliente = new Label("Universidad del saber");
        cliente.setFont(Font.font(18));
        cliente.setWrapText(true);
        
        Label equipo = new Label("(c) Grupo 10: Maria Fernanda Martinez, Moises Vergara, Gabriela Garcia");
        equipo.setWrapText(true);

        Button botonAceptar = new Button("Cerrar");
        botonAceptar.setOnAction(e -> {
            e.consume();
            escenario.close();
        });

        contenedor.getChildren().addAll(nombrePrograma, cliente, equipo, botonAceptar);
    }
}
