package edu.edd.vista;

import javafx.scene.SubScene;
import javafx.scene.layout.VBox;

public class VistaInicio extends SubScene {

    private final VBox contenedor;

    public VistaInicio(double ancho, double alto) {
        super(new VBox(), ancho, alto);
        contenedor = (VBox) getRoot();
    }

    public VBox getContenedor() {
        return contenedor;
    }

}
