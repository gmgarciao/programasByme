package edu.edd.vista.proyecto;

import edu.edd.controlador.ControladorProyecto;
import edu.edd.controlador.ControladorUsuario;
import edu.edd.controlador.ControladorVistas;
import edu.edd.modelo.Estudiante;
import edu.edd.modelo.Proyecto;
import edu.edd.modelo.Tarea;
import edu.edd.modelo.Usuario;
import edu.edd.recurso.dominio.Contenedor;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.SubScene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.scene.text.Font;

public class VistaListarProyectos extends SubScene {

    private VBox contenedor;
    private final BorderPane panelPrimario;
    private Pane panelCentral;
    private Usuario usuario;

    private ObservableList<Proyecto> proyectos;

    public VistaListarProyectos(Usuario usuario, BorderPane panelPrimario,
            Pane panelCentral, double ancho, double alto) {
        super(new VBox(12), ancho, alto);
        this.usuario = usuario;
        this.panelPrimario = panelPrimario;
        this.panelCentral = panelCentral;
        contenedor = (VBox) getRoot();
        contenedor.setAlignment(Pos.TOP_LEFT);
        contenedor.setPadding(new Insets(20, 40, 20, 40));

        if (usuario.getClass().equals(Estudiante.class)) {
            Estudiante estudiante = (Estudiante) usuario;
            proyectos = estudiante.getProyectosEstudiante();
        } else {
            proyectos = ControladorProyecto.cargarProyectos();
        }

        construirInterfaz();
    }

    private String getTextoMiembros(ObservableList<String> miembrosProyecto) {
        String texto = miembrosProyecto.stream()
                .map(miembro -> miembro + ", ")
                .reduce(String::concat)
                .get();
        return texto.substring(0, texto.length() - 2);
    }

    private String getTextoEstado(boolean completitud) {
        if (completitud) {
            return "Finalizado";
        } else {
            return "En proceso";
        }
    }

    public VBox getContenedor() {
        return contenedor;
    }

    private void construirInterfaz() {
        Label titulo = new Label("Proyectos");
        if (Estudiante.class.equals(usuario.getClass())) {
            titulo.setText("Mis Proyectos");
        }
        titulo.setFont(Font.font(24));
        Button botonCrearProyecto = new Button("Crear Proyecto");
        botonCrearProyecto.setOnAction((e) -> {
            panelCentral = ControladorVistas.crearProyecto(usuario, panelPrimario,
                    panelCentral, Contenedor.CUERPO.getAncho(),
                    Contenedor.CUERPO.getAlto());
            panelPrimario.setCenter(null);
            panelPrimario.setCenter(panelCentral);
        });
        contenedor.getChildren().addAll(titulo, botonCrearProyecto);
        mostrarProyectos();
    }

    private void mostrarProyectos() {
        for (Proyecto proyecto : proyectos) {
            Hyperlink tituloProyecto = new Hyperlink(proyecto.getTituloProyecto());
            tituloProyecto.setFont(Font.font(18));
            tituloProyecto.setPadding(Insets.EMPTY);
            tituloProyecto.setOnAction((e) -> {
                panelCentral = ControladorVistas.verDetallesProyecto(usuario, proyecto,
                        panelPrimario, panelCentral, Contenedor.CUERPO.getAncho(),
                        Contenedor.CUERPO.getAlto());
                panelPrimario.setCenter(null);
                panelPrimario.setCenter(panelCentral);
            });

            Label descripcionProyecto = new Label(proyecto.getDescripcionProyecto());
            descripcionProyecto.setWrapText(true);

            Label miembrosProyecto
                    = new Label(getTextoMiembros(proyecto.getMiembrosProyecto()));
            miembrosProyecto.setTextFill(Color.grayRgb(125));
            VBox informacion = new VBox(tituloProyecto, descripcionProyecto, miembrosProyecto);
            informacion.setPrefWidth(contenedor.widthProperty().get() * 0.45);

            ObservableList<Tarea> tareasIncompletasProyecto
                    = proyecto.getTareasIncompletasProyecto();
            
            Hyperlink ntareasIncompletasProyecto
                    = new Hyperlink(Integer.toString(tareasIncompletasProyecto.size())
                            + " tarea(s) pendiente(s)");
            ntareasIncompletasProyecto.setPrefWidth(contenedor.widthProperty().get() * 0.25);
            ntareasIncompletasProyecto.setAlignment(Pos.CENTER);
            ntareasIncompletasProyecto.setOnAction((e) -> {
                panelCentral = ControladorVistas.manejarTareas(usuario, proyecto,
                        panelPrimario, panelCentral, Contenedor.CUERPO.getAncho(),
                        Contenedor.CUERPO.getAlto());
                panelPrimario.setCenter(null);
                panelPrimario.setCenter(panelCentral);
            });
            
            if (!Estudiante.class.equals(usuario.getClass())) {
                ntareasIncompletasProyecto.setDisable(true);
                ntareasIncompletasProyecto.setTextFill(Color.BLACK);
                ntareasIncompletasProyecto.setOpacity(1);
            }

            Label estadoProyecto
                    = new Label(getTextoEstado(proyecto.getCompletitudProyecto()));
            estadoProyecto.setPrefWidth(contenedor.widthProperty().get() * 0.25);
            estadoProyecto.setAlignment(Pos.CENTER);

            Button botonOpciones = new Button();
            SVGPath svg = new SVGPath();
            svg.setContent("M0 0 8 0 M0 4 8 4 M0 8 8 8");
            svg.setStroke(Color.BLACK);
            botonOpciones.setGraphic(svg);
            botonOpciones.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
            botonOpciones.setPrefWidth(contenedor.widthProperty().get() * 0.05);

            MenuItem opcionDetalles = new MenuItem("Ver detalles");
            opcionDetalles.setOnAction((e) -> {
                panelCentral = ControladorVistas.verDetallesProyecto(usuario, proyecto,
                        panelPrimario, panelCentral, Contenedor.CUERPO.getAncho(),
                        Contenedor.CUERPO.getAlto());
                panelPrimario.setCenter(null);
                panelPrimario.setCenter(panelCentral);
            });
            MenuItem opcionEditar = new MenuItem("Editar informacion");
            opcionEditar.setOnAction((e) -> {
                panelCentral = ControladorVistas.editarProyecto(usuario, proyecto,
                        panelPrimario, panelCentral, Contenedor.CUERPO.getAncho(),
                        Contenedor.CUERPO.getAlto());
                panelPrimario.setCenter(null);
                panelPrimario.setCenter(panelCentral);
            });
            MenuItem opcionManejarTareas = new MenuItem("Manejar tareas");
            opcionManejarTareas.setOnAction((e) -> {
                panelCentral = ControladorVistas.manejarTareas(usuario, proyecto,
                        panelPrimario, panelCentral, Contenedor.CUERPO.getAncho(),
                        Contenedor.CUERPO.getAlto());
                panelPrimario.setCenter(null);
                panelPrimario.setCenter(panelCentral);
            });
            MenuItem opcionEliminar = new MenuItem("Eliminar");
            opcionEliminar.setOnAction((e) -> {
                if (ControladorProyecto.eliminar(proyecto)) {
                    if (Estudiante.class.equals(usuario.getClass())) {
                        Estudiante estudiante = (Estudiante) usuario;
                        ObservableList<Proyecto> proyectosEstudiante = estudiante.getProyectosEstudiante();
                        int indice = proyectosEstudiante.indexOf(proyecto);
                        proyectosEstudiante.remove(indice);
                        estudiante.setProyectosEstudiante(proyectosEstudiante);
                        estudiante = (Estudiante) ControladorUsuario.actualizar(usuario).orElseThrow();
                        proyectos = estudiante.getProyectosEstudiante();
                        usuario = estudiante;
                        contenedor.getChildren().clear();
                        construirInterfaz();
                    } else {
                        proyectos = ControladorProyecto.cargarProyectos();
                        contenedor.getChildren().clear();
                        construirInterfaz();
                    }
                }
            });

            ContextMenu menuOpciones = new ContextMenu(opcionDetalles);
            if (usuario.getClass().equals(Estudiante.class)) {
                menuOpciones.getItems().addAll(opcionEditar, opcionManejarTareas, opcionEliminar);
            }
            botonOpciones.setContextMenu(menuOpciones);
            botonOpciones.setOnAction(e -> {
                botonOpciones.getContextMenu().show(botonOpciones, Side.BOTTOM, 0, 0);
            });

            HBox item = new HBox(informacion, ntareasIncompletasProyecto,
                    estadoProyecto, botonOpciones);
            item.setPadding(new Insets(20));
            item.setAlignment(Pos.CENTER);
            item.setBorder(new Border(new BorderStroke(Color.grayRgb(200),
                    BorderStrokeStyle.SOLID, new CornerRadii(12), BorderWidths.DEFAULT)));

            contenedor.getChildren().add(item);
        }
    }
}
