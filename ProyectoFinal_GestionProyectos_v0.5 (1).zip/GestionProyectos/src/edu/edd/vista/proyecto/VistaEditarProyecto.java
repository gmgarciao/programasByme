package edu.edd.vista.proyecto;

import edu.edd.controlador.ControladorProyecto;
import edu.edd.controlador.ControladorUsuario;
import edu.edd.controlador.ControladorVistas;
import edu.edd.modelo.Estudiante;
import edu.edd.modelo.Proyecto;
import edu.edd.recurso.dominio.Contenedor;
import java.util.List;
import java.util.Optional;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.SubScene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.scene.text.Font;
import javafx.stage.Modality;

public class VistaEditarProyecto extends SubScene {

    private final VBox contenedor;
    private final GridPane formulario;
    private final BorderPane panelPrimario;
    private Pane panelCentral;

    private final Estudiante usuario;
    private final Proyecto proyecto;
    private final List<String> miembrosAgregados;

    public VistaEditarProyecto(Estudiante usuario, Proyecto proyecto,
            BorderPane panelPrimario, Pane panelCentral, double ancho,
            double alto) {
        super(new VBox(12), ancho, alto);
        contenedor = (VBox) getRoot();
        contenedor.setAlignment(Pos.TOP_LEFT);
        contenedor.setPadding(new Insets(20, 40, 20, 40));
        formulario = new GridPane();

        miembrosAgregados = proyecto.getMiembrosProyecto();
        proyecto.getTareasProyecto();

        this.usuario = usuario;
        this.proyecto = proyecto;
        this.panelPrimario = panelPrimario;
        this.panelCentral = panelCentral;

        construirFormulario(ancho * 0.8);

        contenedor.getChildren().add(formulario);
    }

    public VBox getContenedor() {
        return contenedor;
    }

    private void agregarMiembro(String miembro, Pane panelMiembros) {
        Button nuevo = new Button(miembro.trim());

        SVGPath cruz = new SVGPath();
        cruz.setContent("M0 0 6 6 M6 0 0 6");
        cruz.setStroke(Color.BLACK);
        nuevo.setGraphic(cruz);
        nuevo.setContentDisplay(ContentDisplay.RIGHT);
        nuevo.setGraphicTextGap(8);

        nuevo.setOnAction(t -> {
            t.consume();
            Node source = (Node) t.getSource();
            int indice = panelMiembros.getChildren().indexOf(source);
            panelMiembros.getChildren().remove(indice);
            miembrosAgregados.remove(indice);
        });

        panelMiembros.getChildren().add(nuevo);
    }

    private void construirFormulario(double ancho) {
        formulario.setPrefWidth(ancho);
        formulario.setAlignment(Pos.TOP_CENTER);
        formulario.setHgap(10);
        formulario.setVgap(10);

        double columna1 = ancho * 0.4;
        double columna2 = ancho * 0.55;

        formulario.getColumnConstraints().addAll(new ColumnConstraints(columna1),
                new ColumnConstraints(columna2));

        Label titulo = new Label("Editar Informacion del Proyecto");
        titulo.setFont(Font.font(24));
        formulario.add(titulo, 0, 0, 2, 1);

        Label labelTituloProyecto = new Label("Titulo Proyecto:");
        TextField campoTituloProyecto = new TextField(proyecto.getTituloProyecto().trim());

        formulario.add(labelTituloProyecto, 0, 1);
        formulario.add(campoTituloProyecto, 1, 1);

        Label labelDescripcionProyecto = new Label("Descripcion:");
        TextArea campoDescripcionProyecto = new TextArea(proyecto.getDescripcionProyecto().trim());
        campoDescripcionProyecto.setWrapText(true);

        formulario.add(labelDescripcionProyecto, 0, 2);
        formulario.add(campoDescripcionProyecto, 1, 2);

        Label labelNuevoMiembroProyecto = new Label("Miembros del Proyecto:");

        VBox vistaMiembros = new VBox(5);
        FlowPane miembros = new FlowPane(Orientation.HORIZONTAL);
        miembros.setHgap(5);

        miembrosAgregados.forEach(miembro -> {
            if (!miembro.equals(usuario.getNombreUsuario())) {
                agregarMiembro(miembro, miembros);
            }
        });

        HBox nuevoMiembro = new HBox(5);
        TextField campoNuevoMiembroProyecto = new TextField();
        Button botonAgregarMiembro = new Button("+");
        botonAgregarMiembro.setOnAction(e -> {
            e.consume();
            String input = campoNuevoMiembroProyecto.getText().trim();
            if (!input.isBlank() && !miembrosAgregados.contains(input)) {
                agregarMiembro(input, miembros);
                miembrosAgregados.add(input);
                campoNuevoMiembroProyecto.setText("");
            }
        });
        nuevoMiembro.getChildren()
                .addAll(campoNuevoMiembroProyecto, botonAgregarMiembro);

        vistaMiembros.getChildren().addAll(miembros, nuevoMiembro);

        formulario.add(labelNuevoMiembroProyecto, 0, 3);
        formulario.add(vistaMiembros, 1, 3);

        CheckBox fueCompletado = new CheckBox("Completado");
        fueCompletado.setSelected(proyecto.getCompletitudProyecto());

        formulario.add(fueCompletado, 1, 4);

        Button botonGuardar = new Button("Guardar cambios");
        botonGuardar.setOnAction((e) -> {
            String tituloProyecto = campoTituloProyecto.getText();
            String descripcionProyecto = campoDescripcionProyecto.getText();
            boolean completitudProyecto = fueCompletado.isSelected();
            Optional<Proyecto> proyectoActualizado = ControladorProyecto
                    .actualizar(proyecto, tituloProyecto, descripcionProyecto,
                            miembrosAgregados, completitudProyecto);
            if (proyectoActualizado.isPresent()) {
                Estudiante usuarioActualizado = (Estudiante) ControladorUsuario
                        .obtenerUsuarioPorId(usuario.getIdUsuario()).orElseThrow();

                panelCentral = ControladorVistas.verProyectos(usuarioActualizado, panelPrimario,
                        panelCentral, Contenedor.CUERPO.getAncho(),
                        Contenedor.CUERPO.getAlto());
                panelPrimario.setCenter(null);
                panelPrimario.setCenter(panelCentral);
            } else {
                Alert mensaje = new Alert(Alert.AlertType.ERROR,
                        "Por favor revise la información.", ButtonType.CLOSE);
                mensaje.initModality(Modality.APPLICATION_MODAL);
                mensaje.show();
            }

        });
        Button botonCancelar = new Button("Cancelar");
        botonCancelar.setOnAction(e -> {
            panelCentral = ControladorVistas.verProyectos(usuario, panelPrimario,
                    panelCentral, Contenedor.CUERPO.getAncho(), Contenedor.CUERPO.getAlto());
            panelPrimario.setCenter(null);
            panelPrimario.setCenter(panelCentral);
        });
        formulario.add(new HBox(12, botonCancelar, botonGuardar), 0, 5, 2, 1);
    }

}
