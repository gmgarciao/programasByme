/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.edd.vista.proyecto;

import edu.edd.controlador.ControladorProyecto;
import edu.edd.controlador.ControladorTarea;
import edu.edd.controlador.ControladorVistas;
import edu.edd.modelo.Estudiante;
import edu.edd.modelo.Proyecto;
import edu.edd.modelo.Tarea;
import edu.edd.modelo.Usuario;
import edu.edd.recurso.dominio.Contenedor;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.SubScene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

/**
 *
 * @author axel
 */
public class VistaDetalladaProyecto extends SubScene {

    private final VBox contenedor;
    private final BorderPane panelPrimario;
    private Pane panelCentral;
    private final Usuario usuario;
    private Proyecto proyecto;
    private ObservableList<Tarea> tareasProyecto;

    public VistaDetalladaProyecto(Usuario usuario, Proyecto proyecto,
            BorderPane panelPrimario, Pane panelCentral, double ancho,
            double alto) {
        super(new VBox(12), ancho, alto);
        this.panelPrimario = panelPrimario;
        this.panelCentral = panelCentral;
        this.proyecto = proyecto;
        this.usuario = usuario;

        contenedor = (VBox) getRoot();
        contenedor.setAlignment(Pos.TOP_LEFT);
        contenedor.setPadding(new Insets(20, 40, 20, 40));

        tareasProyecto = proyecto.getTareasProyecto();
        construirInterfaz();
    }

    public VBox getContenedor() {
        return contenedor;
    }

    private String getTextoMiembros(ObservableList<String> miembrosProyecto) {
        String texto = miembrosProyecto.stream()
                .map(miembro -> miembro + ", ")
                .reduce(String::concat)
                .get();
        return texto.substring(0, texto.length() - 2);
    }

    private String getTextoEstadoProyecto(boolean completitud) {
        if (completitud) {
            return "Finalizado";
        } else {
            return "En proceso";
        }
    }

    private String getTextoEstadoTarea(boolean completitud) {
        if (completitud) {
            return "Completada";
        } else {
            return "Pendiente";
        }
    }

    private void construirInterfaz() {
        Label titulo = new Label(proyecto.getTituloProyecto());
        titulo.setFont(Font.font(24));

        Button botonRegresar = new Button("Regresar");
        botonRegresar.setOnAction(e -> {
            panelCentral = ControladorVistas.verProyectos(usuario, panelPrimario,
                    panelCentral, Contenedor.CUERPO.getAncho(), Contenedor.CUERPO.getAlto());
            panelPrimario.setCenter(null);
            panelPrimario.setCenter(panelCentral);
        });

        Button botonManejarTareas = new Button("Manejar tareas");
        botonManejarTareas.setOnAction((e) -> {
            panelCentral = ControladorVistas.manejarTareas(usuario, proyecto, panelPrimario,
                    panelCentral, Contenedor.CUERPO.getAncho(), Contenedor.CUERPO.getAlto());
            panelPrimario.setCenter(null);
            panelPrimario.setCenter(panelCentral);
        });

        Label labelDescripcion = new Label("Descripcion:");
        Label contenidoDescripcion = new Label(proyecto.getDescripcionProyecto());
        contenidoDescripcion.setWrapText(true);
        VBox descripcion = new VBox(6, labelDescripcion, contenidoDescripcion);

        Label miembros = new Label("Estudiantes vinculados: " + getTextoMiembros(proyecto.getMiembrosProyecto()));

        Label estado = new Label(getTextoEstadoProyecto(proyecto.getCompletitudProyecto()));

        TitledPane seccionTareas = new TitledPane();
        seccionTareas.setText("Tareas");
        VBox listaTareas = new VBox();
        configurarLista(listaTareas, tareasProyecto);
        seccionTareas.setContent(listaTareas);

        HBox botones = new HBox(12, botonRegresar);
        if (Estudiante.class.equals(usuario.getClass())) {
            botones.getChildren().add(botonManejarTareas);
        }
        contenedor.getChildren().addAll(titulo, botones, descripcion, miembros,
                estado, seccionTareas);
    }

    private void configurarLista(VBox lista, ObservableList<Tarea> tareas) {
        lista.setSpacing(12);
        lista.prefWidthProperty().bind(contenedor.widthProperty()
                .subtract(contenedor.paddingProperty().get().getLeft())
                .subtract(contenedor.paddingProperty().get().getRight()));

        if (tareas.isEmpty()) {
            lista.getChildren().add(new Label("No hay tareas"));
        } else {
            HBox titulos = new HBox(0);
            titulos.prefWidthProperty().bind(lista.widthProperty());

            Label colTitulo = new Label("Titulo");
            colTitulo.setUnderline(true);
            colTitulo.prefWidthProperty().bind(titulos.widthProperty().multiply(0.3));

            Label colDescripcion = new Label("Descripcion");
            colDescripcion.setUnderline(true);
            colDescripcion.prefWidthProperty().bind(titulos.widthProperty().multiply(0.3));

            Label colResponsable = new Label("Responsable");
            colResponsable.setUnderline(true);
            colResponsable.prefWidthProperty().bind(titulos.widthProperty().multiply(0.2));

            Label colEstado = new Label("Estado");
            colEstado.setUnderline(true);
            colEstado.prefWidthProperty().bind(titulos.widthProperty().multiply(0.15));

            titulos.getChildren().addAll(colTitulo, colDescripcion, colResponsable,
                    colEstado);
            lista.getChildren().add(titulos);
            for (Tarea tarea : tareas) {
                HBox item = new HBox();
                item.setAlignment(Pos.CENTER_LEFT);
                item.prefWidthProperty().bind(lista.widthProperty());

                Label titulo = new Label(tarea.getTituloTarea());
                Label descripcion = new Label(tarea.getDescripcionTarea());
                descripcion.setWrapText(true);

                titulo.prefWidthProperty().bind(item.widthProperty().multiply(0.3));
                descripcion.prefWidthProperty().bind(item.widthProperty().multiply(0.3));

                Label responsable = new Label(tarea.getResponsableTarea());
                responsable.prefWidthProperty().bind(item.widthProperty().multiply(0.2));

                Label estado = new Label(getTextoEstadoTarea(tarea.getCompletitudTarea()));
                estado.prefWidthProperty().bind(item.widthProperty().multiply(0.15));

                MenuItem opcionDetalles = new MenuItem("Ver detalles");
                MenuItem opcionEditar = new MenuItem("Editar informacion");

                Button botonOpciones = new Button();
                SVGPath svg = new SVGPath();
                svg.setContent("M0 0 8 0 M0 4 8 4 M0 8 8 8");
                svg.setStroke(Color.BLACK);
                botonOpciones.setGraphic(svg);
                botonOpciones.setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
                botonOpciones.prefWidthProperty().bind(item.widthProperty().multiply(0.05));

                opcionEditar.setOnAction((e) -> {
                    panelCentral = ControladorVistas.editarTarea(usuario, proyecto,
                            tarea, panelPrimario, panelCentral,
                            Contenedor.CUERPO.getAncho(), Contenedor.CUERPO.getAlto());
                    panelPrimario.setCenter(null);
                    panelPrimario.setCenter(panelCentral);
                });
                MenuItem opcionEliminar = new MenuItem("Eliminar");
                opcionEliminar.setOnAction((e) -> {
                    if (ControladorTarea.eliminar(tarea)) {
                        int indice = tareasProyecto.indexOf(tarea);
                        tareasProyecto.remove(indice);
                        proyecto.setTareasProyecto(tareasProyecto);
                        proyecto = ControladorProyecto.actualizar(proyecto).orElseThrow();
                        tareasProyecto = proyecto.getTareasProyecto();
                        contenedor.getChildren().clear();
                        construirInterfaz();
                    }
                });

                if (usuario.getClass().equals(Estudiante.class)) {
                    botonOpciones.setContextMenu(new ContextMenu(opcionDetalles,
                            opcionEditar, opcionEliminar));
                    botonOpciones.setOnAction(e -> {
                        botonOpciones.getContextMenu().show(botonOpciones, Side.BOTTOM, 0, 0);
                    });
                }

                item.getChildren().addAll(titulo, descripcion, responsable, estado,
                        botonOpciones);
                lista.getChildren().add(item);
            }
        }
    }
}
