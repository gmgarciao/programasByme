package edu.edd.vista.usuario;

import edu.edd.controlador.ControladorUsuario;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Modality;

public class DialogoCrearUsuario {

    private final Dialog<Boolean> dialogo;
    private final VBox contenedor;
    private final GridPane formulario;

    public DialogoCrearUsuario(double ancho, double alto) {
        contenedor = new VBox();

        double anchoFormulario = ancho * 0.8;
        formulario = new GridPane();

        contenedor.setPadding(new Insets(20));
        contenedor.getChildren().add(formulario);

        dialogo = new Dialog<>();
        dialogo.setTitle("Registrese");
        dialogo.getDialogPane().setContent(contenedor);
        dialogo.getDialogPane().setPrefSize(ancho, alto);

        construirFormulario(anchoFormulario);
    }

    public Dialog<Boolean> getDialogo() {
        return dialogo;
    }

    private void construirFormulario(double ancho) {
        formulario.setPrefWidth(ancho);
        formulario.setAlignment(Pos.TOP_CENTER);
        formulario.setHgap(10);
        formulario.setVgap(10);

        double columna1 = ancho * 0.4;
        double columna2 = ancho * 0.55;

        formulario.getColumnConstraints().addAll(new ColumnConstraints(columna1),
                new ColumnConstraints(columna2));

        Label titulo = new Label("Registrese");
        titulo.setFont(Font.font(24));
        formulario.add(titulo, 0, 0, 2, 1);

        Label labelTipo = new Label("Rol:");
        ComboBox<String> seleccionTipo = new ComboBox<>();
        seleccionTipo.getItems().add("Estudiante");
        seleccionTipo.getItems().add("Administrador");
        formulario.add(labelTipo, 0, 1);
        formulario.add(seleccionTipo, 1, 1);

        Label labelNombre = new Label("Nombre:");
        TextField campoNombre = new TextField();
        formulario.add(labelNombre, 0, 2);
        formulario.add(campoNombre, 1, 2);

        ButtonType botonTipoContinuar = new ButtonType("Continuar", ButtonBar.ButtonData.OK_DONE);
        ButtonType botonTipoCancelar = new ButtonType("Cancelar", ButtonBar.ButtonData.CANCEL_CLOSE);
        dialogo.getDialogPane().getButtonTypes()
                .addAll(botonTipoContinuar, botonTipoCancelar);
        dialogo.setResultConverter((ButtonType p) -> p.getButtonData() == ButtonBar.ButtonData.OK_DONE);
        dialogo.getDialogPane().lookupButton(botonTipoContinuar)
                .addEventFilter(ActionEvent.ACTION, (e) -> {
                    if (campoNombre.getText().isBlank() || seleccionTipo.getValue() == null) {
                        e.consume();
                        Alert mensaje = new Alert(Alert.AlertType.ERROR,
                                "Por favor, rellene todos los campos.", ButtonType.CLOSE);
                        mensaje.initModality(Modality.APPLICATION_MODAL);
                        mensaje.show();
                    } else {
                        if (ControladorUsuario.grabar(seleccionTipo.getValue(),
                                campoNombre.getText()).isPresent()) {
                            dialogo.close();
                        } else {
                            e.consume();
                            Alert mensaje = new Alert(Alert.AlertType.ERROR,
                                    "Por favor, revise la informacion", ButtonType.CLOSE);
                            mensaje.initModality(Modality.APPLICATION_MODAL);
                            mensaje.show();
                        }
                    }
                });
    }

}
