package edu.edd.vista.usuario;

import edu.edd.controlador.ControladorUsuario;
import edu.edd.modelo.Usuario;
import edu.edd.recurso.dominio.Contenedor;
import java.util.function.Consumer;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

public class VistaSeleccionarUsuario {

    private final VBox contenedor;
    private final Consumer<Usuario> callbackSeleccion;

    private ObservableList<Usuario> usuarios;

    public VistaSeleccionarUsuario(Consumer<Usuario> callbackSeleccion,
            double ancho, double alto) {
        contenedor = new VBox(12);
        contenedor.setPadding(new Insets(40, 0, 0, 0));
        contenedor.setAlignment(Pos.TOP_CENTER);
        this.callbackSeleccion = callbackSeleccion;
        usuarios = ControladorUsuario.cargar();
        construirInterfaz();
    }

    public VBox getContenedor() {
        return contenedor;
    }

    private void construirInterfaz() {
        if (usuarios.isEmpty()) {
            DialogoCrearUsuario dialogoCrearUsuario = new DialogoCrearUsuario(400, 300);
            Dialog<Boolean> dialogo = dialogoCrearUsuario.getDialogo();

            dialogo.showAndWait().ifPresent((r) -> {
                if (r) {
                    usuarios = ControladorUsuario.cargar();
                    construirMenuUsuarios();
                } else {
                    System.exit(0);
                }
            });
        } else {
            construirMenuUsuarios();
        }
    }

    private void construirMenuUsuarios() {
        contenedor.getChildren().clear();
        Label titulo = new Label("Seleccione su cuenta");
        titulo.setFont(Font.font(24));
        contenedor.getChildren().add(titulo);
        for (Usuario usuario : usuarios) {
            Button item = new Button(usuario.getNombreUsuario());
            item.setPadding(new Insets(6));
            item.setMaxWidth(Contenedor.CUERPO.getAncho() * 0.5);
            item.setFont(Font.font(18));
            item.setTextAlignment(TextAlignment.LEFT);
            item.setAlignment(Pos.CENTER_LEFT);

            item.setOnAction((e) -> {
                if (callbackSeleccion != null) {
                    callbackSeleccion.accept(usuario);
                }
            });
            contenedor.getChildren().add(item);
        }
        Separator separador = new Separator(Orientation.HORIZONTAL);
        separador.setMaxWidth(Contenedor.CUERPO.getAncho() * 0.5);

        Button botonCrearUsuario = new Button("Crear nuevo Usuario");
        botonCrearUsuario.setPadding(new Insets(6));
        botonCrearUsuario.setMaxWidth(Contenedor.CUERPO.getAncho() * 0.5);
        botonCrearUsuario.setFont(Font.font(18));

        botonCrearUsuario.setOnAction((e) -> {
            DialogoCrearUsuario dialogoCrearUsuario = new DialogoCrearUsuario(400, 300);
            Dialog<Boolean> dialogo = dialogoCrearUsuario.getDialogo();

            dialogo.showAndWait().ifPresent((r) -> {
                if (r) {
                    usuarios = ControladorUsuario.cargar();
                    construirMenuUsuarios();
                } else {
                    System.exit(0);
                }
            });
        });

        contenedor.getChildren().addAll(separador, botonCrearUsuario);
    }
}
