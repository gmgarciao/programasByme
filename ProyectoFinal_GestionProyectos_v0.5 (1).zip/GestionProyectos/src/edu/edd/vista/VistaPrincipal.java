package edu.edd.vista;

import edu.edd.controlador.ControladorUsuario;
import edu.edd.controlador.ControladorVistas;
import edu.edd.modelo.Usuario;
import edu.edd.recurso.dominio.Configuracion;
import edu.edd.recurso.dominio.Contenedor;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class VistaPrincipal {

    private final Stage escenario;
    private final Scene escena;
    private final BorderPane panelPrimario;
    private HBox panelSuperior;
    private Pane panelCentral;

    private Usuario usuarioActual;

    public VistaPrincipal(Stage escenario) {
        panelPrimario = new BorderPane();
        ControladorUsuario.cargar();
        usuarioActual = null;

        escena = new Scene(panelPrimario, Configuracion.ANCHO_APP,
                Configuracion.ALTO_APP);

        this.escenario = escenario;
        this.escenario.setScene(escena);

        escenario.setOnShown((e) -> {
            mostrarMenuUsuarios();
        });
    }

    private void mostrarMenuUsuarios() {
        panelCentral = ControladorVistas.seleccionarUsuario((Usuario usuario) -> {
            manejarSeleccion(usuario);
        }, Configuracion.ANCHO_APP, Configuracion.ALTO_APP);
        panelPrimario.setCenter(panelCentral);
    }

    private void manejarSeleccion(Usuario usuario) {
        this.usuarioActual = usuario;

        VistaMenuCabecera vistaMenuCabecera = new VistaMenuCabecera(usuarioActual,
                panelPrimario, panelCentral, Contenedor.CABECERA.getAncho(),
                Contenedor.CABECERA.getAlto());
        panelSuperior = vistaMenuCabecera.getContenedor();
        panelPrimario.setTop(panelSuperior);

        panelCentral = ControladorVistas.verInicio(usuarioActual,
                Contenedor.CUERPO.getAncho(), Contenedor.CUERPO.getAlto());
        panelPrimario.setCenter(panelCentral);
    }
}
