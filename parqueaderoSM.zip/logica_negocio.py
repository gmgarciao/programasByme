import datetime
import time
class Parqueadero:
    puestos_ocupados = set() 
    precios = {
        (6, 6): {'VIP': 18000, 'Platinum': 12000, 'Gold': 6000,},
        (8, 8): {'VIP': 32000, 'Platinum': 24000, 'Gold': 16000, 'Bronze': 8000,},
        (10, 10): {'VIP': 50000, 'Platinum': 40000, 'Gold': 30000, 'Bronze': 20000, 'Standar': 10000}
    }
    dinero_total_recaudado = 0
    total_vehiculos_ingresados = 0

    def __init__(self, cantidad_filas, cantidad_puestos_fila):
        if cantidad_filas == cantidad_puestos_fila:
            if cantidad_filas in (6, 8, 10):
                self.filas = cantidad_filas
                self.puestos_fila = cantidad_puestos_fila
                self.puestos = [[False for _ in range(self.puestos_fila)] for _ in range(self.filas)]
                self.total_puestos = self.puestos_fila * self.filas
                letras_alfabeto = ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J')
                self.letras_filas = letras_alfabeto[:self.filas]
                self.vehiculos_por_zona = {'VIP': 0,'Platinum': 0,'Gold': 0,'Bronze': 0,'Standar': 0}
                self.vehiculos_por_marca = {}
                self.vehiculos_por_año = {}
                self.tiempos_espacios_ocupados = [[0 for _ in range(self.puestos_fila)] for _ in range (self.filas)]
                self.horas_inicio = [[None for _ in range(self.puestos_fila)]for _ in range (self.filas)]
                self.horas_fin = [[ None for _ in range (self.puestos_fila)]for _ in range (self.filas) ]
            else:
                raise ValueError("Dimensiones no válidas para el parqueadero")
        else:
            raise ValueError("Las dimensiones no son de un parqueadero cuadrado")
        
    def asignar_puesto(self, zona_preferencia: str):
        try:
            if zona_preferencia == "VIP":
                for fila in range(self.filas):
                    for columna in range(self.puestos_fila):
                        if fila == 0 or fila == self.filas - 1 or columna == 0 or columna == self.puestos_fila - 1:
                            if (fila, columna) not in Parqueadero.puestos_ocupados:
                                Parqueadero.puestos_ocupados.add((fila, columna))
                                self.horas_inicio[fila][columna] = time.time()
                                return (fila, columna)
                raise ValueError("No hay puestos disponibles en el área VIP")
            elif zona_preferencia == "Platinum":
                for fila in range(1, self.filas - 1):
                    for columna in range(1, self.puestos_fila - 1):
                        if fila == 1 or fila == self.filas - 2 or columna == 1 or columna == self.puestos_fila - 2:
                            if (fila, columna) not in Parqueadero.puestos_ocupados:
                                Parqueadero.puestos_ocupados.add((fila, columna))
                                self.horas_inicio[fila][columna] = time.time()
                                return (fila, columna)
                raise ValueError("No hay puestos disponibles en el área Platinum")
            elif zona_preferencia == "Gold":
                for fila in range(2, self.filas - 2):
                    for columna in range(2, self.puestos_fila - 2):
                        if fila == 2 or fila == self.filas - 3 or columna == 2 or columna == self.puestos_fila - 3:
                            if (fila, columna) not in Parqueadero.puestos_ocupados:
                                Parqueadero.puestos_ocupados.add((fila, columna))
                                self.horas_inicio[fila][columna] = time.time()
                                return (fila, columna)
                raise ValueError("No hay puestos disponibles en el área Gold")
            elif zona_preferencia == "Bronze":
                for fila in range(3, self.filas - 3):
                    for columna in range(3, self.puestos_fila - 3):
                        if fila == 3 or fila == self.filas - 4 or columna == 3 or columna == self.puestos_fila - 4:
                            if (fila, columna) not in Parqueadero.puestos_ocupados:
                                Parqueadero.puestos_ocupados.add((fila, columna))
                                self.horas_inicio[fila][columna] = time.time()
                                return (fila, columna)
                raise ValueError("No hay puestos disponibles en el área Bronze")
            elif zona_preferencia == "Standar":
                for fila in range(4, self.filas - 4):
                    for columna in range(4, self.puestos_fila - 4):
                        if fila == 4 or fila == self.filas - 5 or columna == 4 or columna == self.puestos_fila - 5:
                            if (fila, columna) not in Parqueadero.puestos_ocupados:
                                Parqueadero.puestos_ocupados.add((fila, columna))
                                self.horas_inicio[fila][columna] = time.time()
                                return (fila, columna)
                raise ValueError("No hay puestos disponibles en el área Standar")
            else:
                print(f"No hay puestos disponibles en el área {zona_preferencia}")
                return None
        except ValueError as e:
            print(f"Error: {e}")
            return None
        
        return (fila, columna)

    def registrar_salida(self, letra:str, columna:int):
        fila=self.letras_filas.index(letra)
        if (fila,columna) not in Parqueadero.puestos_ocupados:
            raise ValueError ("El puesto no esta ocupado por ningun vehiculo")
        else:
            self.horas_fin[fila][columna]= time.time()
            Parqueadero.puestos_ocupados.remove((fila,columna))
        costo_total = self.calcular_cobro(letra, columna)
        costo_total_entero = costo_total = int(round(costo_total))
        self.dinero_total_recaudado += costo_total_entero
        tiempo_total =  self.horas_fin[fila][columna]-self.horas_inicio[fila][columna]
        self.tiempos_espacios_ocupados[fila][columna]= self.tiempos_espacios_ocupados[fila][columna] + tiempo_total
        dias = tiempo_total // (24 * 3600)
        horas = (tiempo_total % (24 * 3600)) // 3600
        minutos = (tiempo_total % 3600) // 60
        segundos = tiempo_total % 60
        return print(f"Vehiculo salio con exito, tiempo transcurrido: {int(dias)} días, {int(horas)} horas, {int(minutos)} minutos y {int(segundos)} segundos. Costo total a pagar: {costo_total_entero} COP")


    def calcular_cobro(self, letra, columna):
        fila=self.letras_filas.index(letra)
        tiempo_transcurrido = self.horas_fin[fila][columna] - self.horas_inicio[fila][columna]
        tiempo_horas = tiempo_transcurrido / 3600
        precio_por_zona = self.precios[(self.filas, self.puestos_fila)][self.puestos[fila][columna]['Zona de Preferencia']]
     
        costo_total = tiempo_horas * precio_por_zona
        return costo_total
    
    def obtener_reporte_general(self):
        total_puestos_utilizados = self.total_vehiculos_ingresados
        return {
            'dinero_total_recaudado': self.dinero_total_recaudado,
            'total_vehiculos_ingresados': self.total_vehiculos_ingresados,
            'total_puestos_utilizados': total_puestos_utilizados
        }
    
    def obtener_zona_mas_utilizada(self):
        zona_max = max(self.vehiculos_por_zona, key=self.vehiculos_por_zona.get)
        vehiculos_en_zona_max = self.vehiculos_por_zona[zona_max]
        return zona_max, vehiculos_en_zona_max
    
    def obtener_tasa_ocupacion(self):
        puestos_ocupados = len(self.puestos_ocupados)
        tasa_ocupacion = (puestos_ocupados / self.total_puestos) * 100
        return tasa_ocupacion
    
    def obtener_porcentajes_por_marca(self):
        total_vehiculos = sum(self.vehiculos_por_marca.values())
        porcentajes_por_marca = {
            marca: (cantidad / total_vehiculos) * 100 for marca, cantidad in self.vehiculos_por_marca.items()
        }
        return porcentajes_por_marca

    def obtener_porcentajes_por_año(self):
        total_vehiculos = sum(self.vehiculos_por_año.values())
        porcentajes_por_año = {
            año: (cantidad / total_vehiculos) * 100 for año, cantidad in self.vehiculos_por_año.items()
        }
        return porcentajes_por_año
            
    def mostrar_parqueadero(self):
        for fila in range(self.filas):
            print("|", end="")
            for columna in range(self.puestos_fila):
                if (fila, columna) in self.puestos_ocupados:
                    print("[X]", end=" ")
                else:
                    print("[ ]", end=" ")
            print("|")
    
class Usuario:
    def __init__(self, parqueadero):
        self.parqueadero = parqueadero
        self.vehiculos_registrados = []
        self.cedula = None

    
    def calcular_edad(self, fecha_nacimiento):
        fecha_actual = datetime.date.today()
        edad = fecha_actual.year - fecha_nacimiento.year - ((fecha_actual.month, fecha_actual.day) < (fecha_nacimiento.month, fecha_nacimiento.day))
        if fecha_nacimiento.year < 1950:
            raise ValueError("La fecha de nacimiento no puede ser anterior a 1950")
        if edad < 18:
            raise ValueError ("El cliente debe ser mayor de edad")
        return edad


    def registrar_usuario(self, nombre, fecha_nacimiento, sexo, cedula):
        self.nombre_conductor = nombre
        if not self.nombre_conductor.isalpha():
            raise ValueError("El nombre solo puede contener letras")
        self.fecha_nacimiento = fecha_nacimiento
        self.sexo = sexo
        self.cedula = cedula
        if len(cedula)>10 or len(cedula)<8:
            raise ValueError("La cédula debe tener entre 8 y 10 dígitos")
        
    
    def obtener_porcentaje_sexos(self):
        total_hombres = 0
        total_mujeres = 0
        total_vehiculos = 0

        for fila in range(self.parqueadero.filas):
            for columna in range(self.parqueadero.puestos_fila):
                if (fila, columna) in self.parqueadero.puestos_ocupados:
                    datos_vehiculo = self.parqueadero.puestos[fila][columna]
                    if datos_vehiculo['Sexo: '] == 'Hombre':
                        total_hombres += 1
                    elif datos_vehiculo['Sexo: '] == 'Mujer':
                        total_mujeres += 1
                    total_vehiculos += 1
        
        porcentaje_hombres = (total_hombres / total_vehiculos) * 100 if total_vehiculos > 0 else 0
        porcentaje_mujeres = (total_mujeres / total_vehiculos) * 100 if total_vehiculos > 0 else 0

        return porcentaje_hombres, porcentaje_mujeres
    
    def obtener_vehiculos_por_cedula(self, cedula):
        vehiculos_encontrados = [vehiculo for vehiculo in self.vehiculos_registrados if vehiculo['Cedula'] == cedula]
        return vehiculos_encontrados


class Vehiculo:
    def __init__(self, usuario, parqueadero):
        self.usuario = usuario
        self.parqueadero = parqueadero

    def ingresar_vehiculo(self, marca_vehiculo, modelo_vehiculo, año_fabricacion):
        fecha_actual = datetime.datetime.now()
        antiguedad_vehiculo = fecha_actual.year - año_fabricacion
        if antiguedad_vehiculo > 10:
            raise ValueError("El vehículo no puede tener más de 10 años de antigüedad para ingresar al parqueadero")
        edad_conductor = self.usuario.calcular_edad(self.usuario.fecha_nacimiento)
        if edad_conductor < 18:
            raise ValueError("El conductor debe ser mayor de 18 años para ingresar al parqueadero")
        zona_preferencia = input("Ingrese la zona de preferencia (VIP, Platinum, Gold, Bronze o Standar): ")
        puesto_asignado = self.parqueadero.asignar_puesto(zona_preferencia)

        if puesto_asignado is None:
            print(f"No se pudo asignar un puesto en la zona de preferencia {zona_preferencia}.")
            return

        fila, columna = puesto_asignado
        Parqueadero.puestos_ocupados.add((fila, columna))
        self.parqueadero.vehiculos_por_zona[zona_preferencia] += 1
        hora_ingreso = datetime.datetime.now().strftime("%I:%M %p")
        self.parqueadero.puestos[fila][columna] = {
            'Nombre del Conductor': self.usuario.nombre_conductor,
            'Fecha de Nacimiento': self.usuario.fecha_nacimiento,
            'Marca del Vehiculo': marca_vehiculo,
            'Modelo del Vehiculo': modelo_vehiculo,
            "Año de Fabricacion": año_fabricacion,
            'Antiguedad del Vehiculo': antiguedad_vehiculo,
            'Hora de Ingreso': hora_ingreso,
            'Zona de Preferencia': zona_preferencia,
            'Sexo: ': self.usuario.sexo,
        }
        self.parqueadero.total_vehiculos_ingresados += 1
        self.parqueadero.vehiculos_por_marca[marca_vehiculo] = self.parqueadero.vehiculos_por_marca.get(marca_vehiculo, 0) + 1
        self.parqueadero.vehiculos_por_año[año_fabricacion] = self.parqueadero.vehiculos_por_año.get(año_fabricacion, 0) + 1

        self.usuario.vehiculos_registrados.append({
            'Marca': marca_vehiculo,
            'Modelo': modelo_vehiculo,
            'Año': año_fabricacion,
            'Puesto': (self.parqueadero.letras_filas[fila], columna + 1),
            'Cedula': self.usuario.cedula
        })

        print("Vehículo ingresado correctamente en el puesto {},{}.".format(self.parqueadero.letras_filas[fila], columna+1))

    def obtener_datos_vehiculo(self, letra, columna):
        fila=self.parqueadero.letras_filas.index(letra)
        if (fila, columna) in self.parqueadero.puestos_ocupados:
            datos_vehiculo = self.parqueadero.puestos[fila][columna]
            tiempo_transcurrido = time.time() - self.parqueadero.horas_entrada[fila][columna]
            dias = tiempo_transcurrido // (24 * 3600)
            horas = (tiempo_transcurrido % (24 * 3600)) // 3600
            minutos = (tiempo_transcurrido % 3600) // 60
            segundos = tiempo_transcurrido % 60
            datos_vehiculo['Tiempo transcurrido desde la entrada'] = f"{int(dias)} días, {int(horas)} horas, {int(minutos)} minutos y {int(segundos)} segundos"
            return datos_vehiculo
        else:
            return None
    
    class Empresa:
        def _init_(self, nombre:str):
            if len(nombre) == 0:
                raise ValueError("El nombre de la empresa no puede estar vacio.")
            self.nombre = nombre
            self.parqueaderos = []

        

    
        
        

