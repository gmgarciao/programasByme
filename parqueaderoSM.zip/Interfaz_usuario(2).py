from logica_negocio import Parqueadero, Usuario, Vehiculo
import datetime

def menu(parqueadero, usuario, vehiculo_obj):
    while True:
        print(f"Bienvenido a la empresa")
        print("\nPor favor, seleccione una opción:")
        print("1. Mostrar estado del parqueadero")
        print("2. Ingresar un vehículo")
        print("3. Ver detalles de un vehículo ingresado")
        print("4. Registrar Salida")
        print("5. Calcular Porcentaje de Hombres Y Mujeres")
        print("6. Reporte General del Parqueadero")
        print("7. Mostrar Zona Mas utilizada Del Parqueadero")
        print("8. Calcular Tasa De Ocupacion Actual")
        print("9. Calcular Porcentaje Vehiculos Por Marca")
        print("10. Porcentajes de vehículos por año de fabricación")
        print("11. Consultar Vehiculos por Cedula de Usuario")
        print("12. Salir")
        opcion = input("Opción: ")
        if opcion == "1":
            parqueadero.mostrar_parqueadero()
        elif opcion == "2":
            try:
                nombre_conductor = input("Ingrese el nombre del conductor: ")
                if len(nombre_conductor) == 0:
                    raise ValueError("El nombre no puede estar vacio, por favor, ingrese un nombre")
                try:
                    fecha_nacimiento = datetime.datetime.strptime(input("Ingrese la fecha de nacimiento del conductor (YYYY-MM-DD): "), "%Y-%m-%d").date()
                except:
                    raise ValueError("Ingrese una fecha válida en el formato correcto (YYYY-MM-DD).")
                
                sexo = input("Ingrese el sexo biologico del conductor(F = Femenino o M = Masculino): ")
                if sexo not in ['F', 'M']:
                    raise ValueError("El sexo debe ser 'F' o 'M'.")
                if len(sexo) == 0:
                    raise ValueError("El sexo no puede estar vacio, escriba su sexo biologico (F o M)")
                
                cedula = input("Ingrese la cedula del conductor: ")
                if len(cedula) == 0:
                    raise ValueError("La cédula no puede estar vacia, ingrese su cedula")
        
                usuario.registrar_usuario(nombre_conductor,fecha_nacimiento, sexo, cedula)
                marca_vehiculo = input("Ingrese la marca del vehículo: ")
                if len(marca_vehiculo) == 0:
                    raise ValueError("La marca del carro no puede estar vacia")
                modelo_vehiculo = input("Ingrese el modelo del vehículo: ")
                if len(modelo_vehiculo) == 0:
                    raise ValueError("El modelo del carro no puede estar vacio")
                año_fabricacion = int(input("Ingrese el año de Fabricacion: "))
                if not año_fabricacion.isdigit():
                    raise ValueError("Ingrese un año valido")
                vehiculo_obj.ingresar_vehiculo(marca_vehiculo, modelo_vehiculo, año_fabricacion)
            except ValueError as e:
                print("Error:", e)
        elif opcion == "3":
            letra = str(input("Ingrese la letra del puesto: "))
            columna = int(input("Ingrese la columna del puesto: "))
            datos_vehiculo = vehiculo_obj.obtener_datos_vehiculo(letra, columna-1)
            if datos_vehiculo:
                print("Datos del vehículo:")
                for key, value in datos_vehiculo.items():
                    print(f"{key}: {value}")
            else:
                print("No hay un vehículo registrado en ese puesto.")
        elif opcion == "4":
            letra = str(input("Ingrese la letra del puesto: "))
            columna = int(input("Ingrese la columna del puesto: "))
            parqueadero.registrar_salida(letra, columna-1)
        elif opcion == "5":
            porcentaje_hombres, porcentaje_mujeres = usuario.obtener_porcentaje_sexos()
            print("Porcentaje de hombres en el parqueadero:", porcentaje_hombres)
            print("Porcentaje de mujeres en el parqueadero:", porcentaje_mujeres)
        elif opcion == "6":
            reporte = parqueadero.obtener_reporte_general()
            print("Reporte general del parqueadero:")
            print(f"Dinero total recaudado: {reporte['dinero_total_recaudado']} COP")
            print(f"Total de vehículos ingresados: {reporte['total_vehiculos_ingresados']}")
            print(f"Total de puestos utilizados: {reporte['total_puestos_utilizados']}")
        elif opcion == "7":
            zona_mas_utilizada, vehiculos_en_zona_max = parqueadero.obtener_zona_mas_utilizada()
            print(f"La zona más utilizada es: {zona_mas_utilizada} con {vehiculos_en_zona_max} vehículos.")
        elif opcion == "8":
            tasa_ocupacion = parqueadero.obtener_tasa_ocupacion()
            print(f"La tasa de ocupación actual es: {tasa_ocupacion:.2f}")
        elif opcion == "9":
            porcentajes_por_marca = parqueadero.obtener_porcentajes_por_marca()
            print("Porcentajes de vehículos por marca:")
            for marca, porcentaje in porcentajes_por_marca.items():
                print(f"{marca}: {porcentaje:.2f}%")
        elif opcion == "10":
            porcentajes_por_año = parqueadero.obtener_porcentajes_por_año()
            print("Porcentajes de vehículos por año de fabricación:")
            for año, porcentaje in porcentajes_por_año.items():
                print(f"{año}: {porcentaje:.2f}%")
        elif opcion == "11":
            cedula = input("Ingrese la cédula del usuario: ")
            vehiculos_encontrados = usuario.obtener_vehiculos_por_cedula(cedula)
            if vehiculos_encontrados:
                print(f"Vehículos registrados para la cédula {cedula}:")
                for vehiculo in vehiculos_encontrados:
                    print(f"Marca: {vehiculo['Marca']}, Modelo: {vehiculo['Modelo']}, Año: {vehiculo['Año']}, Puesto: {vehiculo['Puesto']}")
            else:
                print(f"No se encontraron vehículos registrados para la cédula {cedula}")
        elif opcion == "12":
            break
        else:
            print("Opción no válida. Por favor, seleccione una opción válida.")

while True:
    try:
        print("1. Parqueadero de 36 Puestos")
        print("2. Parqueadero de 64 Puestos")
        print("3. Parqueadero de 100 Puestos")
        opcion1 = input("Opción: ")
        if opcion1 == "1":
             cantidad_filas = 6
             cantidad_columnas = 6
             parqueadero = Parqueadero(cantidad_filas, cantidad_columnas)
        if opcion1 == "2":
             cantidad_filas = 8
             cantidad_columnas = 8
             parqueadero = Parqueadero(cantidad_filas, cantidad_columnas)
  
        if opcion1 == "3":
             cantidad_filas = 10
             cantidad_columnas = 10
             parqueadero = Parqueadero(cantidad_filas, cantidad_columnas)
    except:
        raise ValueError("Por favor, ingrese dimensiones válidas.")

    usuario = Usuario(parqueadero)
    vehiculo_obj = Vehiculo(usuario,parqueadero)

    menu(parqueadero, usuario, vehiculo_obj)