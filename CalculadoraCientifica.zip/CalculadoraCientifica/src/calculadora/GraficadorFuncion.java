package calculadora;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GraficadorFuncion extends JFrame {

    private XYSeriesCollection conjuntoDatos;
    private JTextField entradaFuncion;

    public GraficadorFuncion(String titulo) {
        super(titulo);
       
        conjuntoDatos = new XYSeriesCollection();
       
        JFreeChart grafico = ChartFactory.createXYLineChart(
                "Función Graficada",
                "X",
                "Y",
                conjuntoDatos,
                PlotOrientation.VERTICAL,
                true, true, false);
        
        ChartPanel panelGrafico = new ChartPanel(grafico);
        panelGrafico.setPreferredSize(new Dimension(800, 600)); //creacion del panel grafico
        setContentPane(panelGrafico);
        
        
        JPanel panelDeEntrada = new JPanel();
        entradaFuncion = new JTextField(20);            //panel para la entrada de la funcion.
        JButton botonGraf = new JButton("Graficar");
        
        panelDeEntrada.add(new JLabel("Ingrese la función por ejemplo x^2: "));
        panelDeEntrada.add(entradaFuncion);
        panelDeEntrada.add(botonGraf);
        
        
        add(panelDeEntrada, BorderLayout.SOUTH); //agrega el panel de entrada en la parte de arriba
        
        // Acción del botón
        botonGraf.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                graficarFuncion(entradaFuncion.getText());
            }
        });
    }

    private void graficarFuncion(String funcion) {
        conjuntoDatos.removeAllSeries(); 
        XYSeries serie = new XYSeries("f(x)= " + funcion);
        
        
        for (double x = -10; x <= 10; x += 0.1) {
            double y = evaluarFuncion(funcion, x); //el rango de los valores
            serie.add(x, y);
        }
        
        conjuntoDatos.addSeries(serie);
    }

    private double evaluarFuncion(String funcion, double x) {
        switch (funcion) {
            case "x^2":
                return x * x;
            case "x":
                return x;
            case "x + 1":
                return x + 1;
            case "x - 1":
                return x - 1;
            case "x^3":
                return x * x * x;
            case "sin(x)":
                return Math.sin(x);
            case "cos(x)":
                return Math.cos(x);
            case "exp(x)":
                return Math.exp(x);
            case "tan(x)":
                return Math.tan(x);
            case "log(x)":
                return Math.log(x);
            default:
                return 0; 
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            GraficadorFuncion ejemplo = new GraficadorFuncion("Graficador de Funciones");
            ejemplo.setSize(800, 600);
            ejemplo.setLocationRelativeTo(null);
            ejemplo.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            ejemplo.setVisible(true);
        });
    }
}
